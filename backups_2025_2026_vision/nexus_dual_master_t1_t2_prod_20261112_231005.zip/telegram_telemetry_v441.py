﻿import time
import json
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path
import httpx
import MetaTrader5 as mt5

TELEGRAM_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_TELEGRAM_CHAT_ID"
TERMINAL_PATH = r"C:/MT5_Pending_278041169/terminal64.exe"
TARGET_ACCOUNT = 278041169
MAGIC_NUMBER = 20260440
PROCESSED_DEALS_STATE = Path(r"C:\Quant-Nexus-Eng\telemetry_processed_deals.json")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

def send_telegram_alert(message: str):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "Markdown"}
    try:
        response = httpx.post(url, json=payload, timeout=10.0)
        if response.status_code != 200:
            logging.error(f"Telegram API error: {response.text}")
    except Exception as e:
        logging.error(f"Failed to send Telegram alert: {e}")

def load_processed_deals() -> set:
    if PROCESSED_DEALS_STATE.exists():
        try:
            return set(json.loads(PROCESSED_DEALS_STATE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return set()

def save_processed_deals(processed: set):
    recent = list(processed)[-500:]
    PROCESSED_DEALS_STATE.write_text(json.dumps(recent), encoding="utf-8")

def main():
    if not mt5.initialize(path=TERMINAL_PATH, portable=True):
        logging.error(f"MT5 initialize failed: {mt5.last_error()}")
        return

    processed_deals = load_processed_deals()
    logging.info("V4.4.1 Telegram Telemetry Emitter started. Monitoring Account #278041169...")

    try:
        while True:
            now_dt = datetime.now(timezone.utc)
            deals = mt5.history_deals_get(now_dt - timedelta(hours=2), now_dt + timedelta(minutes=5)) or []
            
            for d in sorted(deals, key=lambda x: x.time):
                if d.magic == MAGIC_NUMBER and d.ticket not in processed_deals:
                    processed_deals.add(d.ticket)
                    action_type = "BUY" if d.type == 0 else "SELL" if d.type == 1 else f"TYPE {d.type}"
                    entry_type = "OPEN" if d.entry == 0 else "CLOSE" if d.entry == 1 else "IN/OUT"
                    profit_str = f" | PnL: *${d.profit:+.2f}*" if d.entry == 1 else ""
                    
                    msg = (
                        f"🚨 *V4.4.1 TELEMETRY ALERT* 🚨\n\n"
                        f"📌 *Asset:* `{d.symbol}`\n"
                        f"🔄 *Action:* `{entry_type} {action_type}`\n"
                        f"📊 *Volume:* `{d.volume:.2f} lots`\n"
                        f"💵 *Price:* `{d.price}`{profit_str}\n"
                        f"🆔 *Ticket:* `#{d.ticket}`\n"
                        f"⏱ *Time:* `{datetime.fromtimestamp(d.time, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC`"
                    )
                    send_telegram_alert(msg)
                    logging.info(f"Broadcasted deal #{d.ticket} ({d.symbol} {entry_type}) to Telegram.")
            
            save_processed_deals(processed_deals)
            time.sleep(15)
    except KeyboardInterrupt:
        pass
    finally:
        mt5.shutdown()

if __name__ == "__main__":
    main()
