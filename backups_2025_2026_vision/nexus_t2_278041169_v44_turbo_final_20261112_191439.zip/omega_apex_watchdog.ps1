$py = "C:\Program Files\Python312\python.exe"
$eng = "C:\Quant-Nexus-Eng"

$mt5Procs = Get-CimInstance Win32_Process -Filter "Name = 'terminal64.exe'"
if (-not ($mt5Procs | Where-Object { $_.ExecutablePath -match "MT5_Quant_278017866" })) {
    Start-Process -FilePath "C:\MT5_Quant_278017866\terminal64.exe"
    Start-Sleep -Seconds 8
}
if (-not ($mt5Procs | Where-Object { $_.ExecutablePath -match "MT5_Pending_278041169" })) {
    Start-Process -FilePath "C:\MT5_Pending_278041169\terminal64.exe" -ArgumentList "/portable" -WorkingDirectory "C:\MT5_Pending_278041169"
    Start-Sleep -Seconds 8
}
if (-not ($mt5Procs | Where-Object { $_.ExecutablePath -match "MT5_HFT_278041671" })) {
    Start-Process -FilePath "C:\MT5_HFT_278041671\terminal64.exe" -ArgumentList "/portable" -WorkingDirectory "C:\MT5_HFT_278041671"
    Start-Sleep -Seconds 8
}

$pyProcs = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" | Select-Object -ExpandProperty CommandLine
if (-not ($pyProcs -match "nexus_omega_apex_daemon\.py.*T1_QUANT")) {
    Start-Process -FilePath $py -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_Quant_278017866/terminal64.exe`" --magic 44044 --tag T1_QUANT" -WorkingDirectory $eng -WindowStyle Hidden
}
if (-not ($pyProcs -match "nexus_multi_straddle_engine\.py")) {
    Start-Process -FilePath $py -ArgumentList "$eng\nexus_multi_straddle_daemon.py" -WorkingDirectory $eng -WindowStyle Hidden
}
if (-not ($pyProcs -match "nexus_omega_apex_daemon\.py.*T3_HFT")) {
    Start-Process -FilePath $py -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_HFT_278041671/terminal64.exe`" --portable --magic 44045 --tag T3_HFT" -WorkingDirectory $eng -WindowStyle Hidden
}


