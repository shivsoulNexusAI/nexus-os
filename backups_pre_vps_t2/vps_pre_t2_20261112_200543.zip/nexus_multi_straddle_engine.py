﻿# -*- coding: utf-8 -*-
"""
QUANT-NEXUS NEXT-GEN UNIVERSAL MULTI-STRADDLE ENGINE (FINAL PRODUCTION v2)
- Dedicated to Account #278041169 | C:/MT5_Pending_278041169/terminal64.exe (Portable=True)
- Trades: XAUUSD, US30, BTCUSD, EURUSD, GBPUSD, USDJPY (from nexus_straddle_matrix.json)
- Safeguards: Dynamic Spread Floor (2.2x live spread), Broker Min-Lot Enforcement,
  Per-Symbol OCO, 15-Min Anti-Whipsaw Cooldown, and 5s Rapid Profit Protection
"""
import json
import math
import sys
import time
import logging
import urllib.request
from pathlib import Path
from datetime import datetime, timezone
import MetaTrader5 as mt5

BASE_DIR = Path(r"C:\Quant-Nexus-Eng")
LOG_FILE = BASE_DIR / "nexus_multi_straddle.log"
CONFIG_FILE = BASE_DIR / "nexus_straddle_matrix.json"
STATE_FILE = BASE_DIR / "state_T2_STRADDLE_999222.json"
TG_CONFIG = BASE_DIR / "t2_telegram_config.json"

MAGIC_NUMBER = 999222
SCAN_INTERVAL_SEC = 60
FAST_GUARD_SEC = 5
COOLDOWN_AFTER_FILL_SEC = 900  # 15-min anti-whipsaw cooldown per symbol after a bracket triggers

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [UTC] [T2_STRADDLE] %(levelname)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger("NexusUniversalEngine")

def load_config() -> dict:
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))

def send_tg(msg: str):
    if not TG_CONFIG.exists():
        return
    try:
        cfg = json.loads(TG_CONFIG.read_text(encoding="utf-8-sig"))
        token, chat_id = cfg.get("bot_token"), cfg.get("authorized_chat_id")
        if token and chat_id:
            payload = json.dumps({"chat_id": chat_id, "text": msg, "parse_mode": "HTML"}).encode("utf-8")
            req = urllib.request.Request(
                f"https://api.telegram.org/bot{token}/sendMessage",
                data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=6) as resp:
                resp.read()
    except Exception as e:
        log.warning("Telegram notify skipped: %s", e)

def load_state(equity: float) -> dict:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    if STATE_FILE.exists():
        try:
            st = json.loads(STATE_FILE.read_text(encoding="utf-8-sig"))
            if st.get("date") == today:
                st.setdefault("t1_done", [])
                st.setdefault("t2_done", [])
                st.setdefault("symbol_cooldowns", {})
                return st
        except Exception:
            pass
    st = {
        "date": today,
        "start_equity": round(equity, 2),
        "halted": False,
        "t1_done": [],
        "t2_done": [],
        "symbol_cooldowns": {}
    }
    save_state(st)
    return st

def save_state(st: dict):
    STATE_FILE.write_text(json.dumps(st, indent=2), encoding="utf-8")

def get_filling_mode(sym_info):
    modes = sym_info.filling_mode
    if modes & 1:
        return mt5.ORDER_FILLING_FOK
    if modes & 2:
        return mt5.ORDER_FILLING_IOC
    return mt5.ORDER_FILLING_RETURN

def get_symbol_exposure(symbol: str) -> float:
    pos_vol = sum(float(p.volume) for p in (mt5.positions_get(symbol=symbol) or []) if p.magic == MAGIC_NUMBER)
    ord_vol = sum(float(o.volume_current) for o in (mt5.orders_get(symbol=symbol) or []) if o.magic == MAGIC_NUMBER)
    return round(pos_vol + ord_vol, 2)

def manage_oco_and_fast_profit(cfg: dict, st: dict):
    """5-second Per-Symbol OCO cancellation + Matrix Tier-1 BE Lock & Tier-2 Harvest."""
    asset_matrix = cfg.get("asset_matrix", {})
    positions = [p for p in (mt5.positions_get() or []) if p.magic == MAGIC_NUMBER]
    orders = [o for o in (mt5.orders_get() or []) if o.magic == MAGIC_NUMBER]
    changed = False

    # 1. Per-Symbol OCO: Cancel opposite pending stop immediately on bracket fill + record 15m cooldown
    pos_symbols = {p.symbol for p in positions}
    for sym in pos_symbols:
        st["symbol_cooldowns"][sym] = time.time() + COOLDOWN_AFTER_FILL_SEC
        changed = True

    for o in orders:
        if o.symbol in pos_symbols:
            res_rm = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
            if res_rm and res_rm.retcode == mt5.TRADE_RETCODE_DONE:
                log.info("[OCO CANCEL] Removed opposite pending #%s (%s) after bracket fill (15m cooldown set)", o.ticket, o.symbol)

    if not positions:
        if changed:
            save_state(st)
        return

    for p in positions:
        sym = p.symbol
        spec = asset_matrix.get(sym)
        if not spec:
            continue
        sym_info = mt5.symbol_info(sym)
        if not sym_info:
            continue

        point = sym_info.point
        digits = sym_info.digits
        is_buy = (p.type == mt5.ORDER_TYPE_BUY)
        entry = float(p.price_open)
        mark = float(p.price_current)
        sl = float(p.sl)

        gain_pts = ((mark - entry) if is_buy else (entry - mark)) / point
        t1_pts = float(spec["be_tier1_points"])
        lock_pts = float(spec["be_lock_points"])
        t2_pts = float(spec["be_tier2_points"])
        harvest_pct = float(spec.get("harvest_pct", 0.5))

        # Tier 1: Rapid Breakeven Lock
        if gain_pts >= t1_pts and p.ticket not in st["t1_done"]:
            target_sl = round(entry + (lock_pts * point) if is_buy else entry - (lock_pts * point), digits)
            needs_move = (target_sl > sl + 0.5 * point or sl == 0.0) if is_buy else (target_sl < sl - 0.5 * point or sl == 0.0)
            if needs_move:
                res = mt5.order_send({
                    "action": mt5.TRADE_ACTION_SLTP, "position": p.ticket,
                    "symbol": sym, "sl": target_sl, "tp": p.tp
                })
                if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                    st["t1_done"].append(p.ticket)
                    changed = True
                    log.info("[TIER 1 BE-LOCK] #%s %s +%.1f pts -> SL locked @ %s", p.ticket, sym, gain_pts, target_sl)
                    send_tg(f"🛡️ <b>[T2 STRADDLE BE-LOCK]</b> #{p.ticket} <b>{sym}</b> +{gain_pts:.0f} pts — SL locked @ <code>{target_sl}</code>")

        # Tier 2: 50% Partial Harvest + Profit Lock
        if gain_pts >= t2_pts and p.ticket not in st["t2_done"]:
            step = sym_info.volume_step if sym_info.volume_step > 0 else 0.01
            close_vol = math.floor((p.volume * harvest_pct) / step) * step
            if close_vol >= sym_info.volume_min and (p.volume - close_vol) >= sym_info.volume_min:
                tick = mt5.symbol_info_tick(sym)
                px = tick.bid if is_buy else tick.ask
                ctype = mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY
                res_c = mt5.order_send({
                    "action": mt5.TRADE_ACTION_DEAL, "position": p.ticket, "symbol": sym,
                    "volume": round(close_vol, 2), "type": ctype, "price": px,
                    "deviation": 25, "magic": MAGIC_NUMBER, "comment": "NX_HARVEST_50",
                    "type_filling": get_filling_mode(sym_info)
                })
                if res_c and res_c.retcode == mt5.TRADE_RETCODE_DONE:
                    log.info("[TIER 2 HARVEST] #%s %s closed %.2f lots @ +%.1f pts", p.ticket, sym, close_vol, gain_pts)
                    send_tg(f"💰 <b>[T2 STRADDLE HARVEST]</b> #{p.ticket} <b>{sym}</b> closed <code>{close_vol:.2f}</code> lots at +{gain_pts:.0f} pts")

            trail_sl = round(entry + (t1_pts * 0.6 * point) if is_buy else entry - (t1_pts * 0.6 * point), digits)
            mt5.order_send({
                "action": mt5.TRADE_ACTION_SLTP, "position": p.ticket,
                "symbol": sym, "sl": trail_sl, "tp": p.tp
            })
            st["t2_done"].append(p.ticket)
            changed = True

    if changed:
        save_state(st)

def evaluate_and_deploy_brackets(cfg: dict, st: dict):
    """60-second continuous evaluation deploying spread-safe BUY_STOP / SELL_STOP brackets."""
    if st.get("halted", False):
        return

    asset_matrix = cfg.get("asset_matrix", {})
    max_open_brackets = int(cfg.get("global_risk", {}).get("max_open_brackets", 4))
    now = time.time()

    orders = [o for o in (mt5.orders_get() or []) if o.magic == MAGIC_NUMBER]
    positions = [p for p in (mt5.positions_get() or []) if p.magic == MAGIC_NUMBER]

    # Refresh drifted brackets if mid-price moved > 2.5x effective buffer away from bracket center
    for sym, spec in asset_matrix.items():
        sym_orders = [o for o in orders if o.symbol == sym]
        if not sym_orders:
            continue
        sym_info = mt5.symbol_info(sym)
        if not sym_info:
            continue
        mid = (sym_info.ask + sym_info.bid) / 2.0
        spread_pts = (sym_info.ask - sym_info.bid) / sym_info.point if sym_info.point > 0 else 0
        eff_buf_pts = max(float(spec["buffer_points"]), spread_pts * 2.2)
        max_drift = (eff_buf_pts * 2.5) * sym_info.point
        if any(abs(o.price_open - mid) > max_drift for o in sym_orders):
            for o in sym_orders:
                mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
            log.info("[BRACKET REFRESH] Re-centering drifted straddle on %s", sym)

    orders = [o for o in (mt5.orders_get() or []) if o.magic == MAGIC_NUMBER]
    positions = [p for p in (mt5.positions_get() or []) if p.magic == MAGIC_NUMBER]
    active_bracket_syms = {o.symbol for o in orders} | {p.symbol for p in positions}

    for sym, spec in asset_matrix.items():
        if sym in active_bracket_syms:
            continue
        if len(active_bracket_syms) >= max_open_brackets:
            break
        if now < float(st.get("symbol_cooldowns", {}).get(sym, 0.0)):
            continue

        sym_info = mt5.symbol_info(sym)
        if not sym_info or not sym_info.visible:
            if not mt5.symbol_select(sym, True):
                continue
            sym_info = mt5.symbol_info(sym)

        if not sym_info or sym_info.trade_mode != mt5.SYMBOL_TRADE_MODE_FULL:
            continue

        point = sym_info.point
        digits = sym_info.digits
        ask = sym_info.ask
        bid = sym_info.bid
        if ask <= 0 or bid <= 0 or point <= 0:
            continue

        base_lot = max(float(spec["lot"]), float(sym_info.volume_min))
        max_exp = max(float(spec["max_exposure"]), base_lot * 2.0)
        curr_exp = get_symbol_exposure(sym)
        if curr_exp + (base_lot * 2) > max_exp:
            continue

        # Dynamic Spread Floor: ensure buffer & SL exceed 2.2x live spread + broker stops_level
        spread_pts = (ask - bid) / point
        stops_level = max(int(sym_info.trade_stops_level), 10)
        eff_buf_pts = max(float(spec["buffer_points"]), spread_pts * 2.2, stops_level + 15)
        eff_sl_pts = max(float(spec["sl_points"]), spread_pts * 2.5, stops_level + 20)
        eff_tp_pts = max(float(spec["be_tier2_points"]) * 1.5, eff_sl_pts * 1.5)

        buf_px = eff_buf_pts * point
        sl_px = eff_sl_pts * point
        tp_px = eff_tp_pts * point

        buy_price = round(ask + buf_px, digits)
        buy_sl = round(buy_price - sl_px, digits)
        buy_tp = round(buy_price + tp_px, digits)

        sell_price = round(bid - buf_px, digits)
        sell_sl = round(sell_price + sl_px, digits)
        sell_tp = round(sell_price - tp_px, digits)

        group_id = f"NX_{int(time.time())}_{sym}"
        filling = get_filling_mode(sym_info)

        buy_req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": sym,
            "volume": round(base_lot, 2),
            "type": mt5.ORDER_TYPE_BUY_STOP,
            "price": buy_price,
            "sl": buy_sl,
            "tp": buy_tp,
            "deviation": 25,
            "magic": MAGIC_NUMBER,
            "comment": f"{group_id}_B",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling
        }
        res_b = mt5.order_send(buy_req)
        if not res_b or res_b.retcode != mt5.TRADE_RETCODE_DONE:
            log.warning("BUY_STOP failed for %s: %s", sym, getattr(res_b, "comment", mt5.last_error()))
            continue

        sell_req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": sym,
            "volume": round(base_lot, 2),
            "type": mt5.ORDER_TYPE_SELL_STOP,
            "price": sell_price,
            "sl": sell_sl,
            "tp": sell_tp,
            "deviation": 25,
            "magic": MAGIC_NUMBER,
            "comment": f"{group_id}_S",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling
        }
        res_s = mt5.order_send(sell_req)
        if not res_s or res_s.retcode != mt5.TRADE_RETCODE_DONE:
            log.warning("SELL_STOP failed for %s (%s). Reverting BUY_STOP #%s", sym, getattr(res_s, "comment", mt5.last_error()), res_b.order)
            mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": res_b.order})
            continue

        active_bracket_syms.add(sym)
        log.info("[BRACKET DEPLOYED] %s | Lots: %.2f | BuyStop: %s (#%s) | SellStop: %s (#%s)",
                 sym, base_lot, buy_price, res_b.order, sell_price, res_s.order)
        send_tg(
            f"⚡ <b>[T2 MULTI-STRADDLE ARMED]</b>\n"
            f"• Asset: <b>{sym}</b> | Lots: <b>{base_lot:.2f}</b>\n"
            f"• BUY_STOP: <code>{buy_price}</code> (#{res_b.order})\n"
            f"• SELL_STOP: <code>{sell_price}</code> (#{res_s.order})"
        )

def main():
    cfg = load_config()
    term_path = cfg.get("terminal_path", r"C:/MT5_Pending_278041169/terminal64.exe")
    account = int(cfg.get("account", 278041169))
    portable = bool(cfg.get("portable", True))

    log.info("======================================================================")
    log.info("STARTING UNIVERSAL MULTI-STRADDLE ENGINE (FINAL PRODUCTION v2)")
    log.info("Terminal=%s | Portable=%s | Account=#%s | Magic=%s", term_path, portable, account, MAGIC_NUMBER)
    log.info("======================================================================")

    if not mt5.initialize(path=term_path, portable=portable, timeout=15000):
        log.error("MT5 initialization failed: %s", mt5.last_error())
        sys.exit(1)

    acc = mt5.account_info()
    if not acc or acc.login != account:
        log.error("Account mismatch! Expected #%s, got %s", account, getattr(acc, "login", "None"))
        mt5.shutdown()
        sys.exit(1)

    log.info("Verified Live Connection: Account #%s | Balance=$%.2f | Equity=$%.2f", acc.login, acc.balance, acc.equity)
    send_tg(f"🚀 <b>[T2 MULTI-STRADDLE v2 LIVE]</b> Connected to <b>#{acc.login}</b> (Equity: <b>${acc.equity:,.2f}</b>) — Spread-Safe 60s Straddle + OCO + 15m Anti-Whipsaw active.")

    last_scan_ts = 0.0
    while True:
        try:
            cfg = load_config()
            acc = mt5.account_info()
            if not acc:
                log.warning("MT5 IPC dropped — reconnecting...")
                mt5.shutdown()
                time.sleep(2)
                mt5.initialize(path=term_path, portable=portable, timeout=15000)
                continue

            st = load_state(acc.equity)
            max_dd_pct = float(cfg.get("global_risk", {}).get("max_account_drawdown_pct", 3.0))
            dd_pct = ((st["start_equity"] - acc.equity) / st["start_equity"]) * 100.0 if st["start_equity"] > 0 else 0.0
            if dd_pct >= max_dd_pct and not st["halted"]:
                st["halted"] = True
                save_state(st)
                log.warning("[CIRCUIT BREAKER] Daily DD %.2f%% >= %.1f%%. Halting new straddles.", dd_pct, max_dd_pct)

            # 1. Every 5s: Per-Symbol OCO + Rapid Profit Protection (BE Lock & 50% Harvest)
            manage_oco_and_fast_profit(cfg, st)

            # 2. Every 60s: Continuous Multi-Asset BUY_STOP / SELL_STOP Straddle Scan
            now = time.time()
            if (now - last_scan_ts) >= SCAN_INTERVAL_SEC:
                evaluate_and_deploy_brackets(cfg, st)
                last_scan_ts = now

            time.sleep(FAST_GUARD_SEC)
        except Exception as exc:
            log.error("[STRADDLE LOOP ERROR] %s", exc)
            time.sleep(5)

if __name__ == "__main__":
    main()
