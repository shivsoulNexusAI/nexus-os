import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

acc = mt5.account_info()
positions = mt5.positions_get() or []
orders = mt5.orders_get() or []

print("=" * 85)
print(f"QUANT-NEXUS PRODUCTION STATE | Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f} | Free Margin: ${acc.margin_free:,.2f}")
print("=" * 85)
print(f"ACTIVE RUNNERS: {len(positions)}")
for p in positions:
    side = "BUY" if p.type == 0 else "SELL"
    pts = (p.price_current - p.price_open) if side == "BUY" else (p.price_open - p.price_current)
    print(f"  -> #{p.ticket:<10} {p.symbol:<7} {side} {p.volume:.2f} lots | Entry: {p.price_open:.5f} | Mark: {p.price_current:.5f} | Move: {pts:>+8.2f} pts | Floating: ${p.profit:>+6.2f} | SL: {p.sl:.5f}")

print(f"\nPENDING BRACKET ORDERS: {len(orders)}")
for o in orders:
    t = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
    print(f"  -> #{o.ticket:<10} {o.symbol:<7} {t:<9} {o.volume_current:.2f} lots | Price: {o.price_open:.5f} | SL: {o.sl:.5f} | TP: {o.tp:.5f}")
print("=" * 85)
mt5.shutdown()