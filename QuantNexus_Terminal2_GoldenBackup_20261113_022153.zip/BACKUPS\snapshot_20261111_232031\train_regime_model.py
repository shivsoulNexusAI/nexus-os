# -*- coding: utf-8 -*-
"""
QUANT-NEXUS REGIME MODEL TRAINER
Trains a high-speed GBDT regime classifier to differentiate
Expansion (Regime 1) from Mean-Reverting Noise/Chop (Regime 0).
"""
import sys
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, precision_score, recall_score, brier_score_loss

DATA_IN = Path(r"C:\Quant-Nexus-Eng\ml_regime_dataset.parquet")
MODEL_OUT = Path(r"C:\Quant-Nexus-Eng\regime_classifier.pkl")

FEATURES = [
    "natr14", "atr_expansion_ratio", "parkinson_vol", "garman_klass_vol",
    "upper_wick_ratio", "lower_wick_ratio", "body_ratio", "rvol",
    "ret_1", "ret_3", "ret_12", "is_btc", "is_gold", "is_us30"
]

def train_classifier():
    if not DATA_IN.exists():
        print(f"[-] Dataset {DATA_IN} not found. Run ml_feature_pipeline.py first.")
        sys.exit(1)

    df = pd.read_parquet(DATA_IN)
    df.sort_values("time", inplace=True)
    df.reset_index(drop=True, inplace=True)

    # 80/20 Chronological Forward Walk Split
    split_idx = int(len(df) * 0.80)
    train_df = df.iloc[:split_idx]
    test_df = df.iloc[split_idx:]

    X_train, y_train = train_df[FEATURES], train_df["target_expansion"].astype(int)
    X_test, y_test = test_df[FEATURES], test_df["target_expansion"].astype(int)

    print("=" * 80)
    print("           TRAINING VOLATILITY REGIME CLASSIFIER")
    print("=" * 80)
    print(f"Training Samples   : {len(X_train)}")
    print(f"Validation Samples : {len(X_test)}")
    print(f"Features           : {len(FEATURES)}")

    clf = HistGradientBoostingClassifier(
        max_iter=150,
        learning_rate=0.05,
        max_depth=5,
        min_samples_leaf=40,
        l2_regularization=1.5,
        random_state=42
    )
    clf.fit(X_train, y_train)

    probs_test = clf.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, probs_test)
    brier = brier_score_loss(y_test, probs_test)

    # Calibrate performance at the P >= 0.65 deployment threshold
    pred_65 = (probs_test >= 0.65).astype(int)
    prec_65 = precision_score(y_test, pred_65, zero_division=0)
    rec_65 = recall_score(y_test, pred_65, zero_division=0)
    deploy_rate = np.mean(pred_65) * 100.0

    print("-" * 80)
    print(f"Out-of-Time ROC-AUC       : {auc:.4f}")
    print(f"Brier Calibration Score   : {brier:.4f}")
    print(f"Precision @ P >= 0.65     : {prec_65 * 100:.2f}% (High Confidence Breakouts)")
    print(f"Recall @ P >= 0.65        : {rec_65 * 100:.2f}%")
    print(f"Gated Fleet Deploy Rate   : {deploy_rate:.1f}% of candidate bars")
    print("=" * 80)

    bundle = {
        "model": clf,
        "feature_names": FEATURES,
        "mean_auc": float(auc),
        "decision_threshold": 0.65,
        "trained_timestamp": pd.Timestamp.now(tz="UTC").isoformat()
    }
    joblib.dump(bundle, MODEL_OUT)
    print(f"[+] Regime Classifier successfully serialized to: {MODEL_OUT}")
    print("=" * 80)

if __name__ == "__main__":
    train_classifier()