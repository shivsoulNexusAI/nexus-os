import json
from pathlib import Path

CFG_PATH = Path(r"C:\Quant-Nexus-Eng\nexus_straddle_matrix.json")
if CFG_PATH.exists():
    with open(CFG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    
    # Increase BTCUSD buffer to prevent intra-tick stops_level collisions
    if "BTCUSD" in cfg.get("asset_matrix", {}):
        cfg["asset_matrix"]["BTCUSD"]["buffer_points"] = 550
        cfg["asset_matrix"]["BTCUSD"]["sl_points"] = 400
        cfg["asset_matrix"]["BTCUSD"]["be_tier1_points"] = 400
        cfg["asset_matrix"]["BTCUSD"]["be_tier2_points"] = 800
        
        with open(CFG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        print("[+] Updated BTCUSD buffer parameters in nexus_straddle_matrix.json")