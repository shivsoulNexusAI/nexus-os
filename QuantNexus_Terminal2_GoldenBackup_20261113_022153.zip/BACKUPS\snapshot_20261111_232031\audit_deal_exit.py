import MetaTrader5 as mt5
from datetime import datetime, timezone, timedelta

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

utc_from = datetime.now(timezone.utc) - timedelta(hours=2)
deals = mt5.history_deals_get(utc_from, datetime.now(timezone.utc)) or []

print("=" * 85)
print("             RECENT CLOSED DEALS (LAST 2 HOURS)")
print("=" * 85)
for d in deals:
    if d.entry == 1:  # Deal out (exit)
        side = "SELL (Close Buy)" if d.type == 1 else "BUY (Close Sell)"
        print(f"Deal #{d.ticket:<10} | {d.symbol:<7} | {side:<17} | Lots: {d.volume:.2f} | Exit: {d.price:.5f} | Net PnL: ${d.profit:+,.2f} | Comment: {d.comment}")
print("=" * 85)
mt5.shutdown()