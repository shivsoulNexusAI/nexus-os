import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

acc = mt5.account_info()
positions = mt5.positions_get() or []
orders = mt5.orders_get() or []

print("=" * 80)
print("            QUANT-NEXUS PRODUCTION TELEMETRY SUMMARY")
print("=" * 80)
print(f"Account Login       : {acc.login} ({acc.server})")
print(f"Current Balance     : ${acc.balance:,.2f}")
print(f"Current Equity      : ${acc.equity:,.2f}")
print(f"Session Floating    : ${acc.profit:+,.2f}")
print(f"Free Margin         : ${acc.margin_free:,.2f}")
print(f"Active Positions    : {len(positions)}")
print(f"Pending Brackets    : {len(orders)}")
print("-" * 80)
for p in positions:
    side = "BUY" if p.type == 0 else "SELL"
    print(f"Runner #{p.ticket} | {p.symbol} {side} {p.volume:.2f} lots | Entry: {p.price_open:.5f} | Mark: {p.price_current:.5f} | Floating: ${p.profit:+.2f} | SL: {p.sl:.5f}")
print("=" * 80)
mt5.shutdown()