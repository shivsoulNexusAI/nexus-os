from pathlib import Path
import re

code = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py").read_text(encoding="utf-8", errors="ignore")
lines = code.splitlines()

print("=" * 80)
print("GOLD HFT STRADDLE CONFIGURATION & SPREAD FILTERS")
print("=" * 80)
for idx, l in enumerate(lines[:65]):
    if any(k in l for k in ["ATR", "CHOP", "SPREAD", "OFFSET", "STOP", "TP", "SL", "BUFFER", "MIN_"]):
        print(f"{idx+1:3d}: {l}")
print("=" * 80)