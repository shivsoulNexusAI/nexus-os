from pathlib import Path
import re

gold_script = Path("C:/Quant-Nexus-Eng/gold_hft_straddle_daemon.py")
if gold_script.exists():
    text = gold_script.read_text(encoding="utf-8", errors="ignore")
    print("=" * 80)
    print("GOLD HFT STRADDLE DAEMON AUDIT")
    print("=" * 80)
    # Check MT5 terminal and account references
    logins = re.findall(r"(?:login|account)\s*[:=]\s*(\d{8,10})", text, re.IGNORECASE)
    terminals = re.findall(r"terminal64\.exe", text, re.IGNORECASE)
    print(f"Logins referenced in gold script : {logins}")
    print(f"Terminal references count       : {len(terminals)}")
    print("=" * 80)