import json
from datetime import datetime, timezone
from pathlib import Path
import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
MICRO_PATH = Path(r"C:\Quant-Nexus-Eng\microstructure_state.json")

if not mt5.initialize(path=TERMINAL, portable=False):
    print(f"[-] MT5 init failed: {mt5.last_error()}")
    raise SystemExit(1)

acc = mt5.account_info()
print("=" * 95)
print(f"LIVE MT5 ACCOUNT SNAPSHOT | Account #{acc.login} ({acc.server})")
print("=" * 95)
print(f"Balance     : ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f} | Floating PnL: ${acc.profit:+,.2f}")
print(f"Free Margin : ${acc.margin_free:,.2f} | Margin Level: {acc.margin_level:.1f}% | Leverage: 1:{acc.leverage}")

positions = mt5.positions_get() or []
print("\n" + "-" * 95)
print(f"ACTIVE POSITIONS ({len(positions)})")
print("-" * 95)
if not positions:
    print("No open positions currently.")
else:
    for p in positions:
        side = "BUY" if p.type == 0 else "SELL"
        print(f"#{p.ticket} | {p.symbol:<7} | {side:<4} {p.volume:.2f}L @ {p.price_open} | Now={p.price_current} | SL={p.sl} | TP={p.tp} | PnL=${p.profit:+.2f} | {p.comment}")

orders = mt5.orders_get() or []
print("\n" + "-" * 95)
print(f"WORKING PENDING ORDERS ({len(orders)})")
print("-" * 95)
if not orders:
    print("No pending stop/limit orders currently.")
else:
    type_map = {2: "BUY_LIMIT", 3: "SELL_LIMIT", 4: "BUY_STOP", 5: "SELL_STOP"}
    for o in orders:
        exp = datetime.fromtimestamp(o.time_expiration, tz=timezone.utc).strftime("%H:%M:%S UTC") if o.time_expiration else "GTC"
        print(f"#{o.ticket} | {o.symbol:<7} | {type_map.get(o.type, str(o.type)):<10} {o.volume_current:.2f}L @ {o.price_open} | SL={o.sl} | Exp={exp} | {o.comment}")

print("\n" + "-" * 95)
print("LIVE MICROSTRUCTURE SENTINEL TELEMETRY (microstructure_state.json)")
print("-" * 95)
if MICRO_PATH.exists():
    micro = json.loads(MICRO_PATH.read_text(encoding="utf-8"))
    print(f"Updated At  : {micro.get('updated_at', 'N/A')}")
    for sym, st in micro.get("symbols", {}).items():
        print(f"{sym:<7} | Delta={st.get('delta_pct', 0):+6.1f}% | Chop={str(st.get('inside_poc_chop', False)):<5} | "
              f"VPOC={st.get('vpoc', 0)} | VAL={st.get('val', 0)} | VAH={st.get('vah', 0)} | Ticks={st.get('tick_count', 0)}")
else:
    print("[-] microstructure_state.json not found.")

print("=" * 95)
mt5.shutdown()