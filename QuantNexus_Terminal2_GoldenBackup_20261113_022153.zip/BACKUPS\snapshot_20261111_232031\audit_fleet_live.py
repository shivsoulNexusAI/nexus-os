import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    print("[-] MT5 initialization failed")
    exit(1)

orders = mt5.orders_get() or []
positions = mt5.positions_get() or []

print("=" * 90)
print("OPEN POSITIONS ({}):".format(len(positions)))
for p in positions:
    side = "BUY" if p.type == 0 else "SELL"
    print("  [POS] #{:<10} {:<7} {:<4} {:<5.2f} lots | Entry: {:<10.5f} | Mark: {:<10.5f} | PnL: ${:>+7.2f} | SL: {:<10.5f}".format(
        p.ticket, p.symbol, side, p.volume, p.price_open, p.price_current, float(p.profit), p.sl
    ))

print("\nPENDING ORDERS ({}):".format(len(orders)))
for o in orders:
    t = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
    print("  [ORD] #{:<10} {:<7} {:<9} {:<5.2f} lots | Price: {:<10.5f} | SL: {:<10.5f} | TP: {:<10.5f}".format(
        o.ticket, o.symbol, t, o.volume_current, o.price_open, o.sl, o.tp
    ))
print("=" * 90)

mt5.shutdown()