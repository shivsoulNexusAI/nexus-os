from pathlib import Path

gold_path = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py")
lines = gold_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING BRACKET PLACEMENT LOGIC (LINES 195-255)")
print("=" * 85)

for i in range(194, min(len(lines), 255)):
    print(f"{i+1:4d}: {lines[i]}")

print("=" * 85)