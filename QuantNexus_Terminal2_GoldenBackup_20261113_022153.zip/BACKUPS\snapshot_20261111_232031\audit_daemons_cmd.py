import psutil
import MetaTrader5 as mt5

print("=" * 80)
print("             PROCESS COMMAND LINE & MODULE VERIFICATION")
print("=" * 80)
for p in psutil.process_iter(['pid', 'name', 'cmdline', 'memory_info']):
    try:
        cmd = " ".join(p.info['cmdline'] or [])
        if "python" in p.info['name'].lower() and any(k in cmd.lower() for k in ["nexus", "breakeven", "telegram", "gold", "quantower", "reporter"]):
            ram = p.info['memory_info'].rss / (1024 * 1024)
            print(f"PID {p.info['pid']:<6} | RAM: {ram:>6.1f} MB | CMD: {cmd}")
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
print("=" * 80)