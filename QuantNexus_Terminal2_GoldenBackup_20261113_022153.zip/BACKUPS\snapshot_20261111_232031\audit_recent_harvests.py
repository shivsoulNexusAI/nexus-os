from datetime import datetime, timedelta
import MetaTrader5 as mt5

silos = [
    ("SILO 2 (Nexus AI Bot)", r"C:/MT5_Quant_278017866/terminal64.exe"),
    ("SILO 3 (Nexus Gold 24/7)", r"C:/MT5_HFT_278041671/terminal64.exe")
]

print("=" * 85)
print("REALIZED HARVEST & EXECUTION AUDIT (PAST 3 HOURS)")
print("=" * 85)

for label, term in silos:
    if mt5.initialize(path=term, portable=False, timeout=10000):
        deals = mt5.history_deals_get(datetime.now() - timedelta(hours=3), datetime.now()) or []
        print(f"\n>>> {label} | Deals Count: {len(deals)}")
        for d in deals:
            if d.entry == 1:  # Out / Exit Deal
                t = datetime.fromtimestamp(d.time).strftime("%H:%M:%S")
                print(f"    [{t}] Ticket #{d.ticket} | Order #{d.order} | {d.symbol} {d.volume:.2f}L @ {d.price} | Profit: ${d.profit:+,.2f} | Tag: {d.comment}")
        mt5.shutdown()
    else:
        print(f"[-] Could not connect to {label}")
print("=" * 85)