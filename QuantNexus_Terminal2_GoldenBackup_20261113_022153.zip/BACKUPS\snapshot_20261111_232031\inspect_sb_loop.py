from pathlib import Path
import re

# [DISABLED_V44] sb_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = sb_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
# [DISABLED_V44] print("INSPECTING SURVEILLANCE LOOP & TIME/NEWS FILTERS IN silver_bullet_daemon.py")
print("=" * 85)

# Locate the while True loop or run() function
loop_start = -1
for idx, line in enumerate(lines):
    if "5s Surveillance active" in line or "while True:" in line:
        loop_start = idx
        break

if loop_start != -1:
    for i in range(max(0, loop_start - 5), min(len(lines), loop_start + 45)):
        print(f"{i+1:4d}: {lines[i]}")
else:
    print("[-] Surveillance loop start not found by pattern.")
print("=" * 85)
