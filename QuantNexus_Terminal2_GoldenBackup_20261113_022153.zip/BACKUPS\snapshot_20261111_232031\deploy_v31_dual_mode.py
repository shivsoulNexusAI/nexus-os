from pathlib import Path

# --- PART A: Fix Exness OTC TICK_FLAG_BUY bias in DeltaDivergenceEngine ---
dii_path = Path(r"C:\Quant-Nexus-OS\core\delta_divergence_engine.py")
dii_code = dii_path.read_text(encoding="utf-8")

old_tick_block = """                    if flags & mt5.TICK_FLAG_BUY:
                        ask_vol_total += vol
                        bar_delta += vol
                    elif flags & mt5.TICK_FLAG_SELL:
                        bid_vol_total += vol
                        bar_delta -= vol
                    else:
                        if bid > prev_bid or ask > prev_ask:
                            ask_vol_total += vol
                            bar_delta += vol
                        elif bid < prev_bid or ask < prev_ask:
                            bid_vol_total += vol
                            bar_delta -= vol
                        else:
                            ask_vol_total += vol * 0.5
                            bid_vol_total += vol * 0.5"""

new_tick_block = """                    mid_shift = ((bid - prev_bid) + (ask - prev_ask)) * 0.5
                    if mid_shift > 0:
                        ask_vol_total += vol
                        bar_delta += vol
                    elif mid_shift < 0:
                        bid_vol_total += vol
                        bar_delta -= vol
                    else:
                        ask_vol_total += vol * 0.5
                        bid_vol_total += vol * 0.5"""

if old_tick_block in dii_code:
    dii_code = dii_code.replace(old_tick_block, new_tick_block, 1)
    dii_path.write_text(dii_code, encoding="utf-8")
    print("[OK] Patched DeltaDivergenceEngine with Quote-Shift Tick Rule.")
else:
    print("[INFO] DeltaDivergenceEngine already patched or custom.")

# --- PART B: Wire NexusSignalEngine Secondary Mean-Reversion Mode into V3.1 Daemon ---
daemon_path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
d_code = daemon_path.read_text(encoding="utf-8")

old_import = """try:
    from core.anti_whipsaw import AntiWhipsawEngine
except Exception:
    AntiWhipsawEngine = None"""

new_import = """try:
    from core.anti_whipsaw import AntiWhipsawEngine
    from core.nexus_signal_engine import NexusSignalEngine
except Exception:
    AntiWhipsawEngine = None
    NexusSignalEngine = None"""

assert old_import in d_code, "Import block not found"
d_code = d_code.replace(old_import, new_import, 1)

old_init_tail = """        self.whipsaw = AntiWhipsawEngine(cooldown_sec=900, max_consecutive_losses=2, penalty_sec=3600) if AntiWhipsawEngine else None
        self.processed_deals = set()"""

new_init_tail = """        self.whipsaw = AntiWhipsawEngine(cooldown_sec=900, max_consecutive_losses=2, penalty_sec=3600) if AntiWhipsawEngine else None
        self.fade_engine = NexusSignalEngine(symbols=["XAUUSD", "BTCUSD", "EURUSD"]) if NexusSignalEngine else None
        self.processed_deals = set()"""

assert old_init_tail in d_code, "Init tail not found"
d_code = d_code.replace(old_init_tail, new_init_tail, 1)

# Add helper method evaluate_and_dispatch_fade() before cycle()
fade_method = '''    def evaluate_and_dispatch_fade(self, sym: str, tick, info, engaged_syms: set) -> bool:
        """Secondary Mode: Nexus-OS DII Absorption/Divergence Mean-Reversion at VAL/VAH -> VPOC."""
        if not self.fade_engine or sym not in ("XAUUSD", "BTCUSD", "EURUSD"):
            return False
        micro = self.read_microstructure(sym)
        if not micro or micro.get("inside_poc_chop", True):
            return False

        val = micro.get("val", 0.0)
        vah = micro.get("vah", 0.0)
        buf = info.point * (50 if "BTC" in sym else (30 if "XAU" in sym else 15))

        # Only invoke DII scan when price is actively probing Value Area boundaries
        if not (tick.bid <= val + buf or tick.ask >= vah - buf):
            return False

        sig = self.fade_engine.evaluate_symbol(sym)
        if not sig or sig.get("confidence", 0.0) < 0.65:
            return False

        side = sig["side"]
        price = tick.ask if side == "BUY" else tick.bid
        sl = round(float(sig["sl_price"]), info.digits)
        tp = round(float(sig["tp_price"]), info.digits)
        sl_dist = abs(price - sl)
        tp_dist = abs(tp - price)
        if sl_dist <= 0 or (tp_dist / sl_dist) < 1.3:
            return False

        lot = max(info.volume_min * 2.0, 0.02) if info.volume_min <= 0.01 else info.volume_min
        order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL
        req = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": sym,
            "volume": lot,
            "type": order_type,
            "price": price,
            "sl": sl,
            "tp": tp,
            "deviation": 30,
            "type_filling": mt5.ORDER_FILLING_IOC,
            "comment": "NEXUS_V3_FADE",
        }
        res = mt5.order_send(req)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            engaged_syms.add(sym)
            logging.info(
                f"[V3.1 FADE ARMED | {sig['setup']} | Conf={sig['confidence']:.2f} | VPOC={sig['vpoc']}] "
                f"{sym} {side} {lot}L @ {price:.{info.digits}f} | SL={sl:.{info.digits}f} | TP={tp:.{info.digits}f} (#{res.order})"
            )
            return True
        return False

    def cycle(self):'''

assert "    def cycle(self):" in d_code, "cycle() header not found"
d_code = d_code.replace("    def cycle(self):", fade_method, 1)

# Hook secondary fade evaluation when primary ML breakout gate skips a symbol
old_ml_skip = """                if p_expansion < thresh:
                    continue"""

new_ml_skip = """                if p_expansion < thresh:
                    self.evaluate_and_dispatch_fade(sym, tick, info, engaged_syms)
                    continue"""

assert old_ml_skip in d_code, "ML skip block not found"
d_code = d_code.replace(old_ml_skip, new_ml_skip, 1)

# Also allow DII fade check when XAUUSD/BTCUSD is outside VPOC chop at boundary
old_micro_block = """                        if micro.get("inside_poc_chop", False) or micro.get("regime") == "BALANCED_CHOP":
                            logging.info(
                                f"[MICRO GATE BLOCK] {sym} inside VPOC chop (VPOC={micro.get('vpoc')}, "
                                f"Delta={micro.get('delta_pct')}%, Regime={micro.get('regime')})."
                            )
                            continue"""

new_micro_block = """                        if micro.get("inside_poc_chop", False) or micro.get("regime") == "BALANCED_CHOP":
                            if not micro.get("inside_poc_chop", False):
                                self.evaluate_and_dispatch_fade(sym, tick, info, engaged_syms)
                            continue"""

assert old_micro_block in d_code, "Micro block not found"
d_code = d_code.replace(old_micro_block, new_micro_block, 1)
d_code = d_code.replace("NEXUS ENGINE V3.0 ONLINE", "NEXUS ENGINE V3.1 DUAL-MODE ONLINE (BREAKOUT + DII FADE)")

daemon_path.write_text(d_code, encoding="utf-8")
print("[OK] Upgraded nexus_multi_straddle_daemon.py to V3.1 Dual-Mode Execution.")