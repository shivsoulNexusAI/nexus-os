import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    print("[-] MT5 Init failed")
    exit(1)

acc = mt5.account_info()
if acc:
    print("=" * 85)
    print("      QUANT-NEXUS SILO 2 LIVE VERIFIED ACCOUNT METRICS (#{})".format(acc.login))
    print("=" * 85)
    print("Account Server   : {}".format(acc.server))
    print("Account Currency : {}".format(acc.currency))
    print("Balance          : ${:>12.2f}".format(acc.balance))
    print("Equity           : ${:>12.2f}".format(acc.equity))
    print("Floating PnL     : ${:>+12.2f}".format(acc.profit))
    print("Margin Used      : ${:>12.2f}".format(acc.margin))
    print("Free Margin      : ${:>12.2f}".format(acc.margin_free))
    print("Margin Level     : {:>11.1f}%".format(acc.margin_level))
    print("Credit           : ${:>12.2f}".format(acc.credit))
    print("=" * 85)

mt5.shutdown()