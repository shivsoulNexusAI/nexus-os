import time
import logging
from pathlib import Path
import MetaTrader5 as mt5

from telegram_notifier_v43 import send_v43_alert

TERMINAL_PATH = r"C:/MT5_Quant_278017866/terminal64.exe"
LOG_PATH = Path(r"C:\Quant-Nexus-Eng\breakeven_engine.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [BE-V4.4] %(message)s",
    handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8")],
)

HARVESTED_TICKETS = set()
PEAK_GAIN_BY_TICKET = {}
INIT_RISK_BY_TICKET = {}


def manage_positions():
    positions = mt5.positions_get() or []
    active_tickets = {p.ticket for p in positions}
    for stale in list(PEAK_GAIN_BY_TICKET.keys()):
        if stale not in active_tickets:
            PEAK_GAIN_BY_TICKET.pop(stale, None)
            INIT_RISK_BY_TICKET.pop(stale, None)
            HARVESTED_TICKETS.discard(stale)

    for p in positions:
        if p.sl <= 0:
            continue
        info = mt5.symbol_info(p.symbol)
        tick = mt5.symbol_info_tick(p.symbol)
        if not info or not tick:
            continue

        is_buy = (p.type == mt5.POSITION_TYPE_BUY)
        cur_price = tick.bid if is_buy else tick.ask

        if p.ticket not in INIT_RISK_BY_TICKET:
            INIT_RISK_BY_TICKET[p.ticket] = abs(p.price_open - p.sl)
        init_risk = INIT_RISK_BY_TICKET[p.ticket]
        if init_risk <= 0:
            continue

        cur_gain = (cur_price - p.price_open) if is_buy else (p.price_open - cur_price)
        if cur_gain > PEAK_GAIN_BY_TICKET.get(p.ticket, 0.0):
            PEAK_GAIN_BY_TICKET[p.ticket] = cur_gain

        peak_gain = PEAK_GAIN_BY_TICKET[p.ticket]
        r_mult = cur_gain / init_risk
        peak_r = peak_gain / init_risk

        # Tier 1: +0.85R Fast Breakeven Lock (+0.12R cushion)
        if r_mult >= 0.85:
            be_sl = round(p.price_open + (0.12 * init_risk) if is_buy else p.price_open - (0.12 * init_risk), info.digits)
            needs_be = (is_buy and p.sl < be_sl) or (not is_buy and p.sl > be_sl)
            if needs_be:
                res = mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "position": p.ticket, "symbol": p.symbol, "sl": be_sl, "tp": 0.0})
                if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                    logging.info(f"[TIER 1 +0.85R BE LOCK] {p.symbol} #{p.ticket} SL -> {be_sl}")
                    send_v43_alert(
                        f"🛡️ <b>[V4.4 TIER 1: +0.85R BE LOCK]</b>\n"
                        f"Asset: <b>{p.symbol}</b> (#{p.ticket})\n"
                        f"Protected SL: <code>{be_sl}</code> (+0.12R cushion)"
                    )

        # Tier 2: +1.60R 50% Partial Harvest + +1.05R Floor Ratchet (activates Multi-Session Runner)
        if r_mult >= 1.60 and p.ticket not in HARVESTED_TICKETS and p.volume >= (info.volume_min * 2):
            close_vol = round(p.volume * 0.5, 2)
            close_type = mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY
            res = mt5.order_send({
                "action": mt5.TRADE_ACTION_DEAL,
                "position": p.ticket,
                "symbol": p.symbol,
                "volume": close_vol,
                "type": close_type,
                "price": cur_price,
                "deviation": 30,
                "type_filling": mt5.ORDER_FILLING_IOC,
                "comment": "NEXUS_V44_T2_HARVEST",
            })
            if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                HARVESTED_TICKETS.add(p.ticket)
                ratch_sl = round(p.price_open + (1.05 * init_risk) if is_buy else p.price_open - (1.05 * init_risk), info.digits)
                mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "position": p.ticket, "symbol": p.symbol, "sl": ratch_sl, "tp": 0.0})
                logging.info(f"[TIER 2 +1.60R HARVEST] {p.symbol} #{p.ticket} banked {close_vol}L | Multi-Session Runner Floor SL -> {ratch_sl}")
                send_v43_alert(
                    f"💰 <b>[V4.4 TIER 2: +1.60R 50% HARVEST]</b>\n"
                    f"Asset: <b>{p.symbol}</b> (#{p.ticket})\n"
                    f"Banked: <b>{close_vol}L</b> @ <code>{cur_price}</code>\n"
                    f"Multi-Session Runner SL: <code>{ratch_sl}</code> (+1.05R locked)"
                )

        # Tier 3: 65% Peak-Profit Lock once runner reaches >= +2.20R (never gives back >35% of peak excursion)
        if (p.ticket in HARVESTED_TICKETS or (is_buy and p.sl > p.price_open + init_risk) or (not is_buy and p.sl < p.price_open - init_risk)) and peak_r >= 2.20:
            lock_sl = round(p.price_open + (peak_gain * 0.65) if is_buy else p.price_open - (peak_gain * 0.65), info.digits)
            better = (is_buy and lock_sl > p.sl) or (not is_buy and lock_sl < p.sl)
            if better:
                res = mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "position": p.ticket, "symbol": p.symbol, "sl": lock_sl, "tp": 0.0})
                if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                    logging.info(f"[TIER 3 65% PEAK LOCK] {p.symbol} #{p.ticket} Runner SL -> {lock_sl} (Peak +{peak_r:.2f}R)")
                    send_v43_alert(
                        f"📈 <b>[V4.4 TIER 3: 65% PEAK-PROFIT LOCK]</b>\n"
                        f"Asset: <b>{p.symbol}</b> (#{p.ticket})\n"
                        f"Peak Excursion: <b>+{peak_r:.2f}R</b> | Locked SL: <code>{lock_sl}</code>"
                    )


if __name__ == "__main__":
    if mt5.initialize(path=TERMINAL_PATH, portable=False):
        logging.info("Breakeven & 65% Peak-Profit Lock Multi-Session Runner Engine V4.4 Online.")
        while True:
            try:
                manage_positions()
            except Exception as e:
                logging.error(f"BE loop error: {e}")
            time.sleep(2)