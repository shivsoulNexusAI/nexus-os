from pathlib import Path

# [DISABLED_V44] path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

match_idx = None
for i, line in enumerate(lines):
    if "def check_killzone" in line:
        match_idx = i
        break

if match_idx is not None:
    print("=" * 80)
    print(f"KILLZONE WINDOW SPECIFICATION ({path.name})")
    print("=" * 80)
    for idx in range(match_idx, min(len(lines), match_idx + 40)):
        print(f"{idx+1:4d}: {lines[idx]}")
    print("=" * 80)
else:
    print("[-] Function definition 'def check_killzone' not located.")
