import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

positions = mt5.positions_get() or []
orders = mt5.orders_get() or []

print("=" * 95)
print("ACTIVE POSITIONS ({}) | ARMED PENDING BRACKETS ({})".format(len(positions), len(orders)))
print("=" * 95)
for p in positions:
    side = "BUY" if p.type == 0 else "SELL"
    print("RUNNER #{:<10} {:<7} {} {:<4.2f} lots | Entry: {:<10.5f} | Mark: {:<10.5f} | SL: {:<10.5f} | PnL: ${:>+7.2f}".format(
        p.ticket, p.symbol, side, p.volume, p.price_open, p.price_current, p.sl, p.profit
    ))

for o in orders:
    o_type = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
    print("ORDER  #{:<10} {:<7} {:<9} {:<4.2f} lots | Price: {:<10.5f} | SL: {:<10.5f} | TP: {:<10.5f}".format(
        o.ticket, o.symbol, o_type, o.volume_current, o.price_open, o.sl, o.tp
    ))
print("=" * 95)
mt5.shutdown()