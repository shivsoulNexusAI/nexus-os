import MetaTrader5 as mt5
from datetime import datetime

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False):
    deals = mt5.history_deals_get(position=2855591764) or []
    print("=" * 85)
    print(f"DEAL AUDIT FOR POSITION #2855591764 (Deals Found: {len(deals)})")
    print("=" * 85)
    for d in deals:
        direction = "ENTRY IN" if d.entry == 0 else ("EXIT OUT" if d.entry == 1 else "IN/OUT")
        dt_str = datetime.fromtimestamp(d.time).strftime("%Y-%m-%d %H:%M:%S")
        print(f"Deal #{d.ticket} | {direction:<9} | Vol: {d.volume:.2f}L | Price: {d.price:.2f} | Profit: ${d.profit:+.2f} | {dt_str} | Tag: {d.comment}")
    mt5.shutdown()
    print("=" * 85)