import httpx
import re
from pathlib import Path

# Collect all potential bot tokens across the workspace
candidate_tokens = set()
search_dirs = [Path(r"C:\Quant-Nexus-Eng"), Path(r"C:\Quant-Nexus-Prod")]

for d in search_dirs:
    if not d.exists(): continue
    for p in d.rglob("*.py"):
        try:
            content = p.read_text(encoding="utf-8", errors="ignore")
            matches = re.findall(r"(\d{8,11}:[A-Za-z0-9_-]{35})", content)
            for m in matches:
                candidate_tokens.add(m)
        except Exception:
            pass

print("=" * 80)
print(f"TELEGRAM BOT IDENTIFIER AUDIT ({len(candidate_tokens)} candidates found)")
print("=" * 80)

for tok in candidate_tokens:
    try:
        r = httpx.get(f"https://api.telegram.org/bot{tok}/getMe", timeout=6.0)
        if r.status_code == 200:
            data = r.json().get("result", {})
            b_id = data.get("id")
            b_name = data.get("first_name")
            b_user = data.get("username")
            print(f"Token Prefix : {tok[:10]}...{tok[-5:]}")
            print(f"Bot Name     : {b_name} (@{b_user}) [ID: {b_id}]")
            print("-" * 80)
        else:
            print(f"Token {tok[:10]}... : HTTP {r.status_code} (Invalid / Revoked)")
    except Exception as e:
        print(f"Token {tok[:10]}... : Network Error {e}")
print("=" * 80)