# -*- coding: utf-8 -*-
"""
QUANT-NEXUS SILO 2: PRODUCTION 12-MONTH BACKTEST (2025 - 2026)
Incorporates:
  1. Symbol Auto-Subscription & MarketWatch Pre-Warm
  2. Dynamic Session Compression Filter (Range <= 2.0 * ATR)
  3. Exact PnL Tick Calculations across USDJPY, XAUUSD, US30, BTCUSD, EURUSD, GBPUSD
  4. Real Staged Tier 1 (+1.0R) Lock and Tier 2 (+2.0R) 50% Harvest Mechanics
"""
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timezone

TERMINAL_PATH = r"C:/MT5_Quant_278017866/terminal64.exe"
ACCOUNT = 278041169

if not mt5.initialize(path=TERMINAL_PATH, portable=False):
    print(f"[-] MT5 Init failed: {mt5.last_error()}")
    exit(1)

DATE_FROM = datetime(2025, 11, 1, tzinfo=timezone.utc)
DATE_TO   = datetime(2026, 11, 1, tzinfo=timezone.utc)
INITIAL_CAPITAL = 1000.00

# Fleet Calibration Matrix matching Silo 2 Production
ASSET_CONFIG = {
    "XAUUSD": {"lot": 0.01, "buf_pts": 150, "sl_pts": 150, "t1_pts": 150, "t2_pts": 300, "t1_lock": 50, "t2_ratchet": 100},
    "US30":   {"lot": 0.02, "buf_pts": 45,  "sl_pts": 45,  "t1_pts": 45,  "t2_pts": 90,  "t1_lock": 10, "t2_ratchet": 30},
    "BTCUSD": {"lot": 0.01, "buf_pts": 350, "sl_pts": 300, "t1_pts": 300, "t2_pts": 600, "t1_lock": 60, "t2_ratchet": 200},
    "EURUSD": {"lot": 0.02, "buf_pts": 80,  "sl_pts": 110, "t1_pts": 110, "t2_pts": 220, "t1_lock": 15, "t2_ratchet": 80},
    "GBPUSD": {"lot": 0.02, "buf_pts": 90,  "sl_pts": 120, "t1_pts": 120, "t2_pts": 240, "t1_lock": 20, "t2_ratchet": 80},
    "USDJPY": {"lot": 0.02, "buf_pts": 90,  "sl_pts": 120, "t1_pts": 120, "t2_pts": 240, "t1_lock": 20, "t2_ratchet": 80}
}

print("=" * 115)
print("     QUANT-NEXUS SILO 2: FULL PRODUCTION 12-MONTH HISTORICAL AUDIT (2025 - 2026)")
print("=" * 115)
print(f" Account Monitored: #{ACCOUNT} | Starting Capital: ${INITIAL_CAPITAL:,.2f}")
print(f" History Horizon  : {DATE_FROM.strftime('%Y-%m-%d')} to {DATE_TO.strftime('%Y-%m-%d')}")
print("-" * 115)

portfolio_trades = []
asset_metrics = {}

for sym, cfg in ASSET_CONFIG.items():
    if not mt5.symbol_select(sym, True):
        print(f"[-] Could not activate symbol {sym} in MarketWatch.")
        continue

    rates = mt5.copy_rates_range(sym, mt5.TIMEFRAME_M15, DATE_FROM, DATE_TO)
    if rates is None or len(rates) == 0:
        print(f"[-] Rates empty for {sym}.")
        continue

    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    
    sym_info = mt5.symbol_info(sym)
    point = sym_info.point if sym_info else 0.00001
    digits = sym_info.digits if sym_info else 5

    def calc_pnl(order_type, open_p, close_p, vol):
        p = mt5.order_calc_profit(order_type, sym, vol, open_p, close_p)
        if p is not None:
            return float(p)
        mult = 100.0 if "JPY" in sym else (1.0 if sym in ("US30", "BTCUSD", "XAUUSD") else 100000.0)
        return (close_p - open_p) * mult * vol if order_type == mt5.ORDER_TYPE_BUY else (open_p - close_p) * mult * vol

    # 14-period ATR
    high_low = df['high'] - df['low']
    high_close = (df['high'] - df['close'].shift()).abs()
    low_close = (df['low'] - df['close'].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr'] = tr.rolling(window=56).mean()

    df['date'] = df['time'].dt.date
    daily_groups = df.groupby('date')
    
    trades = []
    
    for date, group in daily_groups:
        if len(group) < 24:
            continue
        
        # Asian Range: first 16 bars (00:00 to 04:00 UTC)
        ref_window = group.iloc[:16]
        ref_high = ref_window['high'].max()
        ref_low  = ref_window['low'].min()
        ref_range = ref_high - ref_low
        atr_val = ref_window['atr'].iloc[-1]

        # Dynamic Volatility Filter (Permissive to capture true session breakouts)
        if pd.notna(atr_val) and ref_range > (2.2 * atr_val):
            continue

        buy_stop = ref_high + (cfg["buf_pts"] * point)
        sell_stop = ref_low - (cfg["buf_pts"] * point)
        sl_dist = cfg["sl_pts"] * point
        t1_dist = cfg["t1_pts"] * point
        t2_dist = cfg["t2_pts"] * point
        
        buy_active = False
        sell_active = False
        
        for idx in range(16, len(group)):
            bar = group.iloc[idx]
            
            if not buy_active and not sell_active:
                if bar['high'] >= buy_stop:
                    buy_active = True
                    entry_p = buy_stop
                    current_sl = entry_p - sl_dist
                    t1_hit = False
                    t2_hit = False
                    rem_vol = cfg["lot"]
                    accum_pnl = 0.0
                elif bar['low'] <= sell_stop:
                    sell_active = True
                    entry_p = sell_stop
                    current_sl = entry_p + sl_dist
                    t1_hit = False
                    t2_hit = False
                    rem_vol = cfg["lot"]
                    accum_pnl = 0.0
                continue
            
            # Position Execution: BUY
            if buy_active:
                if bar['low'] <= current_sl:
                    accum_pnl += calc_pnl(mt5.ORDER_TYPE_BUY, entry_p, current_sl, rem_vol)
                    trades.append({"symbol": sym, "pnl": accum_pnl, "t2_harvest": t2_hit, "win": accum_pnl > 0, "date": date})
                    buy_active = False
                    break
                
                # Tier 1 Lock (+1.0R) -> Move SL into green pad
                if not t1_hit and bar['high'] >= (entry_p + t1_dist):
                    t1_hit = True
                    current_sl = entry_p + (cfg["t1_lock"] * point)
                
                # Tier 2 Harvest (+2.0R) -> Close 50% and ratchet runner
                if not t2_hit and bar['high'] >= (entry_p + t2_dist):
                    t2_hit = True
                    h_vol = round(rem_vol * 0.5, 2)
                    accum_pnl += calc_pnl(mt5.ORDER_TYPE_BUY, entry_p, entry_p + t2_dist, h_vol)
                    rem_vol -= h_vol
                    current_sl = entry_p + (cfg["t2_ratchet"] * point)

            # Position Execution: SELL
            elif sell_active:
                if bar['high'] >= current_sl:
                    accum_pnl += calc_pnl(mt5.ORDER_TYPE_SELL, entry_p, current_sl, rem_vol)
                    trades.append({"symbol": sym, "pnl": accum_pnl, "t2_harvest": t2_hit, "win": accum_pnl > 0, "date": date})
                    sell_active = False
                    break
                
                if not t1_hit and bar['low'] <= (entry_p - t1_dist):
                    t1_hit = True
                    current_sl = entry_p - (cfg["t1_lock"] * point)
                
                if not t2_hit and bar['low'] <= (entry_p - t2_dist):
                    t2_hit = True
                    h_vol = round(rem_vol * 0.5, 2)
                    accum_pnl += calc_pnl(mt5.ORDER_TYPE_SELL, entry_p, entry_p - t2_dist, h_vol)
                    rem_vol -= h_vol
                    current_sl = entry_p - (cfg["t2_ratchet"] * point)

    if trades:
        pnls = [t["pnl"] for t in trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        t2_harvests = sum(1 for t in trades if t["t2_harvest"])
        net_pnl = sum(pnls)
        gp = sum(wins) if wins else 0.0
        gl = abs(sum(losses)) if losses else 0.0
        pf = (gp / gl) if gl > 0 else 99.9
        wr = (len(wins) / len(trades) * 100.0)
        
        asset_metrics[sym] = {
            "trades": len(trades), "net_pnl": net_pnl, "win_rate": wr,
            "t2_harvests": t2_harvests, "pf": pf, "gp": gp, "gl": gl
        }
        portfolio_trades.extend(trades)

print(f"{'ASSET':<8} | {'TRADES':<7} | {'NET PNL':<12} | {'WIN RATE':<9} | {'PF':<6} | {'T2 HARVESTS':<11} | {'GROSS PROFIT':<13} | {'GROSS LOSS':<11}")
print("-" * 115)

for sym, m in sorted(asset_metrics.items(), key=lambda x: x[1]["net_pnl"], reverse=True):
    print(f"{sym:<8} | {m['trades']:<7} | ${m['net_pnl']:>+10.2f} | {m['win_rate']:>7.1f}% | {m['pf']:>5.2f} | {m['t2_harvests']:>11d} | ${m['gp']:>11.2f} | ${m['gl']:>10.2f}")

print("=" * 115)

if portfolio_trades:
    all_pnls = [t["pnl"] for t in portfolio_trades]
    tot_net = sum(all_pnls)
    tot_wins = sum(p for p in all_pnls if p > 0)
    tot_loss = abs(sum(p for p in all_pnls if p <= 0))
    tot_pf = (tot_wins / tot_loss) if tot_loss > 0 else 99.9
    tot_wr = (sum(1 for p in all_pnls if p > 0) / len(portfolio_trades) * 100.0)
    tot_t2 = sum(1 for t in portfolio_trades if t["t2_harvest"])
    final_balance = INITIAL_CAPITAL + tot_net
    roi_pct = (tot_net / INITIAL_CAPITAL) * 100.0

    cum_pnl = np.cumsum(all_pnls)
    equity_curve = INITIAL_CAPITAL + cum_pnl
    peak = np.maximum.accumulate(equity_curve)
    drawdowns = (peak - equity_curve) / peak * 100.0
    max_dd = np.max(drawdowns)

    print("                 CALIBRATED 12-MONTH PORTFOLIO EXECUTIVE AUDIT")
    print("=" * 115)
    print(f" Starting Capital : ${INITIAL_CAPITAL:,.2f}")
    print(f" Final Balance    : ${final_balance:,.2f}  (ROI: {roi_pct:+.1f}%)")
    print(f" Total Setups     : {len(portfolio_trades)} executed trades")
    print(f" Portfolio WinRate: {tot_wr:.1f}%")
    print(f" Profit Factor    : {tot_pf:.2f}")
    print(f" Max Drawdown     : {max_dd:.2f}% (Peak-to-Trough)")
    print(f" Tier 2 Harvests  : {tot_t2} partial profit locks banked")
    print("=" * 115)

mt5.shutdown()