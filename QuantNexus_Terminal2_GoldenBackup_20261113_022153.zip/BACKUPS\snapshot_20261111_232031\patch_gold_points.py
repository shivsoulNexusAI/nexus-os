from pathlib import Path

gold_script = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py")
content = gold_script.read_text(encoding="utf-8", errors="ignore")

# Replace undersized 2-digit assumptions with genuine 3-digit Exness point targets
replacements = {
    "STRADDLE_OFFSET_POINTS = 150": "STRADDLE_OFFSET_POINTS = 1500  # $1.50 dynamic breakout buffer",
    "SL_POINTS = 120":              "SL_POINTS = 2000              # $2.00 stop loss (prevents spread chop)",
    "TP_POINTS = 300":              "TP_POINTS = 4500              # $4.50 target expansion (1:2.25 RR)",
    "CHOP_THRESHOLD = 61.8":        "CHOP_THRESHOLD = 55.0         # Tighter chop filter (blocks quiet consolidation)"
}

modified = False
for old_val, new_val in replacements.items():
    if old_val in content:
        content = content.replace(old_val, new_val)
        modified = True

if modified:
    gold_script.write_text(content, encoding="utf-8")
    print("[+] Successfully recalibrated Gold HFT parameters for 3-digit broker pricing.")
else:
    print("[-] Replacement targets not found or already patched.")