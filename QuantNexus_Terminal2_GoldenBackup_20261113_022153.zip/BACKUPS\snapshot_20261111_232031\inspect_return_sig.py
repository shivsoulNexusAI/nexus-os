from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING get_features() RETURN STATEMENT (LINES 115-136)")
print("=" * 85)
for i in range(114, min(len(lines), 136)):
    print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)