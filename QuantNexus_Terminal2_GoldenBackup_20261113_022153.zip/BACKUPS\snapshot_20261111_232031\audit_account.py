import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    print("[-] MT5 initialization failed")
    exit(1)

acc = mt5.account_info()
if acc:
    print("=" * 80)
    print("         SILO 2 ACCOUNT TELEMETRY & LIQUIDITY SNAPSHOT")
    print("=" * 80)
    print(f"Account Login  : {acc.login} ({acc.server})")
    print(f"Currency       : {acc.currency}")
    print(f"Balance        : ${acc.balance:,.2f}")
    print(f"Equity         : ${acc.equity:,.2f}")
    print(f"Floating Profit: ${acc.profit:+,.2f}")
    print(f"Free Margin    : ${acc.margin_free:,.2f}")
    print(f"Margin Level   : {acc.margin_level:.2f}%" if acc.margin else "Margin Level   : N/A (No utilized margin)")
    print("=" * 80)
mt5.shutdown()