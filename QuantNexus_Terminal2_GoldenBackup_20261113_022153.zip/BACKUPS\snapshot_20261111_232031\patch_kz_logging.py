from pathlib import Path

# [DISABLED_V44] sb_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
content = sb_path.read_text(encoding="utf-8", errors="ignore")

# Make scan_and_execute log standby state every ~60 seconds
old_kz_check = """    in_kz, kz_name = check_killzone()
    if not in_kz:
        return"""

new_kz_check = """    in_kz, kz_name = check_killzone()
    if not in_kz:
        if not hasattr(scan_and_execute, "_last_kz_log") or (time.time() - scan_and_execute._last_kz_log > 60):
            log.info("Standby: Outside ICT Killzone (surveillance active across %s)", FLEET_SYMBOLS)
            scan_and_execute._last_kz_log = time.time()
        return"""

if old_kz_check in content:
    content = content.replace(old_kz_check, new_kz_check)
    sb_path.write_text(content, encoding="utf-8")
    print("[+] Patched scan_and_execute with visible killzone heartbeat logs.")
else:
    print("[-] Exact killzone check snippet not matched.")
