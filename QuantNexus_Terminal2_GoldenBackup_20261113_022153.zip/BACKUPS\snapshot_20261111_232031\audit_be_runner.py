import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

positions = mt5.positions_get(symbol="BTCUSD") or []
print("=" * 80)
print("     BTCUSD DYNAMIC RUNNER & TRAILING THRESHOLD AUDIT")
print("=" * 80)
for p in positions:
    entry = p.price_open
    mark = p.price_current
    sl = p.sl
    # Tier 1 (+1.0 ATR ~ +$100): Locks BE +$10
    be_tier1 = entry + 100.0 if p.type == 0 else entry - 100.0
    # Tier 2 (+2.0 ATR ~ +$200): Locks +1.0 ATR
    be_tier2 = entry + 200.0 if p.type == 0 else entry - 200.0
    
    print(f"Runner Ticket   : #{p.ticket}")
    print(f"Position Type   : {'BUY' if p.type == 0 else 'SELL'} {p.volume:.2f} lots")
    print(f"Entry Price     : {entry:.2f}")
    print(f"Current Mark    : {mark:.2f} | Floating: ${p.profit:+.2f}")
    print(f"Current SL      : {sl:.2f} (Max Risk: ${abs(entry - sl) * p.volume:.2f})")
    print(f"Tier 1 Lock Target : {be_tier1:.2f} (Dist: {abs(be_tier1 - mark):.2f} pts)")
    print(f"Tier 2 Lock Target : {be_tier2:.2f} (Dist: {abs(be_tier2 - mark):.2f} pts)")
print("=" * 80)
mt5.shutdown()