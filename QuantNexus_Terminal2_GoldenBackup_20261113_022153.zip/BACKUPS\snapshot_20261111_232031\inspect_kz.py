from pathlib import Path

# [DISABLED_V44] sb_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = sb_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING check_killzone() DEFINITION")
print("=" * 85)

for idx, line in enumerate(lines):
    if "def check_killzone" in line:
        for i in range(idx, min(len(lines), idx + 35)):
            print(f"{i+1:4d}: {lines[i]}")
        break
print("=" * 85)
