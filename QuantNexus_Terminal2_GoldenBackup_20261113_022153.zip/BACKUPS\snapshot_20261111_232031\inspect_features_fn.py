from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING get_features() IN nexus_multi_straddle_daemon.py")
print("=" * 85)

for idx, line in enumerate(lines):
    if "def get_features" in line:
        for i in range(idx, min(len(lines), idx + 60)):
            print(f"{i+1:4d}: {lines[i]}")
        break
print("=" * 85)