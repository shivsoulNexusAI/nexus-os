import re
import json
from pathlib import Path
import httpx

# 1. Search for live working tokens across known source files
candidate_tokens = set()
search_dirs = [Path("C:/Quant-Nexus-Eng"), Path("C:/Quant-Nexus-Prod")]

for d in search_dirs:
    if not d.exists(): continue
    for ext in ["*.py", "*.json", "*.txt", "*.cfg"]:
        for p in d.rglob(ext):
            try:
                content = p.read_text(encoding="utf-8", errors="ignore")
                matches = re.findall(r"(\d{8,11}:[A-Za-z0-9_-]{35})", content)
                for m in matches:
                    candidate_tokens.add(m)
            except Exception:
                pass

token_map = {}
for tok in candidate_tokens:
    try:
        r = httpx.get(f"https://api.telegram.org/bot{tok}/getMe", timeout=5.0)
        if r.status_code == 200:
            data = r.json().get("result", {})
            b_id = data.get("id")
            b_name = data.get("first_name")
            b_user = data.get("username", "").lower()
            token_map[b_id] = (tok, b_name, b_user)
    except Exception:
        pass

# Match tokens by Bot ID
# Quant Alert Bot: ID 8883861115
# Nexus AI Bot   : ID 8578781048
# Nexus Gold 24/7: ID 9288476562
tok_quant = token_map.get(8883861115, (None, "", ""))[0]
tok_nexus = token_map.get(8578781048, (None, "", ""))[0]
tok_gold  = token_map.get(9288476562, (None, "", ""))[0]

# Fallback for gold from gold_telegram_config.json if not in map
if not tok_gold:
    jpath = Path("C:/Quant-Nexus-Eng/gold_telegram_config.json")
    if jpath.exists():
        tok_gold = json.loads(jpath.read_text(encoding="utf-8")).get("token")

print("=" * 80)
print("EXTRACTED AUTHENTIC TOKENS:")
print(f"Quant Alert Bot Token : {tok_quant[:10] if tok_quant else 'NONE'}...{tok_quant[-5:] if tok_quant else ''}")
print(f"Nexus AI Bot Token    : {tok_nexus[:10] if tok_nexus else 'NONE'}...{tok_nexus[-5:] if tok_nexus else ''}")
print(f"Nexus Gold Bot Token  : {tok_gold[:10] if tok_gold else 'NONE'}...{tok_gold[-5:] if tok_gold else ''}")
print("=" * 80)

# Write exact config files
if tok_quant:
    Path("C:/Quant-Nexus-Eng/telegram_quantower_config.py").write_text(
        f'# -*- coding: utf-8 -*-\nTELEGRAM_BOT_TOKEN = "{tok_quant}"\nTELEGRAM_CHAT_ID = "5279761713"\nTARGET_LOGIN = 278017866\nTERMINAL_PATH = r"C:/Program Files/MetaTrader 5 - Apex Satellite/terminal64.exe"\n',
        encoding="utf-8"
    )

if tok_nexus:
    content = f'# -*- coding: utf-8 -*-\nTELEGRAM_BOT_TOKEN = "{tok_nexus}"\nTELEGRAM_CHAT_ID = "5279761713"\nTARGET_LOGIN = 278041169\nTERMINAL_PATH = r"C:/MT5_Quant_278017866/terminal64.exe"\n'
    Path("C:/Quant-Nexus-Eng/telegram_nexus_config.py").write_text(content, encoding="utf-8")
    Path("C:/Quant-Nexus-Eng/telegram_config.py").write_text(content, encoding="utf-8")

if tok_gold:
    Path("C:/Quant-Nexus-Eng/telegram_gold_config.py").write_text(
        f'# -*- coding: utf-8 -*-\nTELEGRAM_BOT_TOKEN = "{tok_gold}"\nTELEGRAM_CHAT_ID = "5279761713"\nTARGET_LOGIN = 278041671\nTERMINAL_PATH = r"C:/MT5_HFT_278041671/terminal64.exe"\n',
        encoding="utf-8"
    )

# Test dispatch
bots = [
    ("Quant Alert Bot (@Qunatalertbot)", tok_quant, 278017866, "🌐 QUANTOWER MAJORS ONLINE\nAccount #278017866\nScope: ICT / ORB Breakout Grid"),
    ("NEXUS AI BOT👑🔥 (@Nexus_AIk_bot)", tok_nexus, 278041169, "👑🔥 NEXUS AI BOT ONLINE\nAccount #278041169\nScope: Dynamic Multi-Straddle V2 (ML P>=0.75)"),
    ("Nexus Gold 24/7 (@Nexusfurious_bot)", tok_gold, 278041671, "🥇 NEXUS GOLD 24/7 ONLINE\nAccount #278041671\nScope: Pure XAUUSD HFT Engine")
]

for name, tok, acc, desc in bots:
    if not tok:
        print(f"[-] Missing token for {name}")
        continue
    url = f"https://api.telegram.org/bot{tok}/sendMessage"
    payload = {
        "chat_id": "5279761713",
        "text": f"✅ <b>[{name}]</b>\n━━━━━━━━━━━━━━━━━━\n{desc}\n━━━━━━━━━━━━━━━━━━\nHandshake Verified & Strict Isolation Active.",
        "parse_mode": "HTML"
    }
    r = httpx.post(url, json=payload, timeout=8.0)
    print(f"[{'SUCCESS' if r.status_code == 200 else 'FAILED'}] {name}: HTTP {r.status_code}")
print("=" * 80)