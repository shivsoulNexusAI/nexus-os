from datetime import datetime, timezone
import MetaTrader5 as mt5

APEX_TERMINAL = r"C:/Program Files/MetaTrader 5 - Apex Satellite/terminal64.exe"
if mt5.initialize(path=APEX_TERMINAL, portable=False, timeout=10000):
    t_info = mt5.terminal_info()
    tick = mt5.symbol_info_tick("EURUSD")
    server_time = datetime.fromtimestamp(tick.time) if tick else datetime.utcnow()
    utc_now = datetime.now(timezone.utc)
    
    print("=" * 80)
    print(f"TIME CONTEXT: APEX SATELLITE (ACCOUNT #278017866)")
    print("=" * 80)
    print(f"Broker Server Time (Exness) : {server_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Current UTC Time            : {utc_now.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print("=" * 80)
    mt5.shutdown()
else:
    print("[-] Apex MT5 failed to initialize.")