from pathlib import Path

be_path = Path(r"C:\Quant-Nexus-Prod\core\breakeven_engine.py")
if not be_path.exists():
    be_path = Path(r"C:\Quant-Nexus-Eng\breakeven_engine.py")

lines = be_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print(f"INSPECTING BREAKEVEN ENGINE: {be_path.name} ({len(lines)} lines)")
print("=" * 85)

for idx, l in enumerate(lines):
    if any(k in l for k in ["def evaluate_position", "def ratchet", "HARVEST", "1.80", "1.8"]):
        print(f"\n--- Section around line {idx+1}: {l.strip()} ---")
        for i in range(max(0, idx - 2), min(len(lines), idx + 35)):
            print(f"{i+1:4d}: {lines[i]}")
        break
print("=" * 85)