from pathlib import Path

gold_path = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py")
lines = gold_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING sync_gold_straddle() IMPLEMENTATION")
print("=" * 85)

for idx, line in enumerate(lines):
    if "def sync_gold_straddle" in line:
        for i in range(idx, min(len(lines), idx + 60)):
            print(f"{i+1:4d}: {lines[i]}")
        break
print("=" * 85)