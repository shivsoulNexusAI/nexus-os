import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_HFT_278041671/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False, timeout=10000):
    acc = mt5.account_info()
    orders = mt5.orders_get() or []
    tick = mt5.symbol_info_tick("XAUUSD")
    print("=" * 80)
    print(f"CALIBRATED GOLD HFT BRACKET AUDIT (ACCOUNT #{acc.login})")
    print(f"Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f}")
    if tick:
        print(f"XAUUSD Current Spot -> Bid: {tick.bid:.3f} | Ask: {tick.ask:.3f} | Spread: ${(tick.ask - tick.bid):.3f}")
    print(f"Pending Orders: {len(orders)}")
    for o in orders:
        o_type = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
        sl_dist = abs(o.price_open - o.sl)
        tp_dist = abs(o.tp - o.price_open)
        print(f"  -> Order #{o.ticket} | {o_type} {o.volume_current:.2f}L @ {o.price_open:.3f} | SL: {o.sl:.3f} (Δ ${sl_dist:.2f}) | TP: {o.tp:.3f} (Δ ${tp_dist:.2f})")
    print("=" * 80)
    mt5.shutdown()
else:
    print(f"[-] HFT Terminal init failed: {mt5.last_error()}")