import MetaTrader5 as mt5
from datetime import datetime, timezone, timedelta

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    print("[-] MT5 Init failed")
    exit(1)

from_d = datetime.now(timezone.utc) - timedelta(hours=1)
to_d = datetime.now(timezone.utc)
deals = mt5.history_deals_get(from_d, to_d) or []

print("=" * 95)
print("              CLOSED DEALS AUDIT (LAST 60 MINUTES)")
print("=" * 95)
print("{:<12} | {:<7} | {:<5} | {:<10} | {:<11} | {:<7} | {}".format(
    "DEAL", "SYMBOL", "LOTS", "PRICE", "NET PNL", "COMM", "COMMENT"
))
print("-" * 95)

pnl_tot = 0.0
comm_tot = 0.0
count = 0

for d in deals:
    if d.entry == 1:  # ENTRY_OUT (closed executions)
        count += 1
        p = float(d.profit)
        c = float(d.commission)
        pnl_tot += p
        comm_tot += c
        print("{:<12} | {:<7} | {:<5.2f} | {:<10.5f} | ${:>+9.2f} | ${:>5.2f} | {}".format(
            d.ticket, d.symbol, d.volume, d.price, p, c, d.comment
        ))

print("=" * 95)
print("Total Closed Deals : {}".format(count))
print("Gross Profit       : ${:>+10.2f}".format(pnl_tot))
print("Total Commission   : ${:>10.2f}".format(comm_tot))
print("Net Realized       : ${:>+10.2f}".format(pnl_tot + comm_tot))
print("=" * 95)

positions = mt5.positions_get() or []
print("\nACTIVE RUNNER LIVE METRICS ({} OPEN):".format(len(positions)))
for p in positions:
    side = "BUY" if p.type == 0 else "SELL"
    print("  -> #{:<10} {:<7} {} {:<4.2f} lots | Entry: {:<9.5f} | Mark: {:<9.5f} | SL: {:<9.5f} | Floating: ${:>+7.2f}".format(
        p.ticket, p.symbol, side, p.volume, p.price_open, p.price_current, p.sl, float(p.profit)
    ))
print("=" * 95)

mt5.shutdown()