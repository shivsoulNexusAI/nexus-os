import MetaTrader5 as mt5
from datetime import datetime, timezone

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False):
    orders = mt5.orders_get() or []
    print("=" * 85)
    print("ORDER EXPIRATION & TIME-IN-FORCE AUDIT")
    print("=" * 85)
    for o in orders[:6]:
        exp_str = datetime.fromtimestamp(o.time_expiration, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC') if o.time_expiration > 0 else "GTC (No Expiry)"
        print(f"#{o.ticket} | {o.symbol:<7} | Vol: {o.volume_current:.2f}L | TypeTime: {o.type_time} | Expiration: {exp_str}")
    mt5.shutdown()
    print("=" * 85)
else:
    print("[-] MT5 Init failed.")