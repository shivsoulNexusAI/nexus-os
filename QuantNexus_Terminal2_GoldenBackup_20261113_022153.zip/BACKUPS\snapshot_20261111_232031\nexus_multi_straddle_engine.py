# -*- coding: utf-8 -*-
"""
QUANT-NEXUS NEXT-GEN UNIVERSAL MULTI-STRADDLE ENGINE (PRODUCTION)
Trades: XAUUSD, US30, BTCUSD, EURUSD, GBPUSD, USDJPY
Account: #278041169
"""
import os
import json
import time
import logging
from pathlib import Path
from datetime import datetime, timezone
import MetaTrader5 as mt5

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(r"C:\Quant-Nexus-Eng\nexus_multi_straddle.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("NexusUniversalEngine")

CONFIG_FILE = Path(r"C:\Quant-Nexus-Eng\nexus_straddle_matrix.json")
with open(CONFIG_FILE, "r", encoding="utf-8") as f:
    CONFIG = json.load(f)

TERMINAL_PATH = CONFIG.get("terminal_path", r"C:/MT5_Quant_278017866/terminal64.exe")
ACCOUNT = CONFIG.get("account", 278041169)
ASSET_MATRIX = CONFIG.get("asset_matrix", {})

def init_mt5():
    if not mt5.initialize(path=TERMINAL_PATH, portable=False):
        log.error("MT5 initialization failed: %s", mt5.last_error())
        return False
    acc = mt5.account_info()
    if not acc or acc.login != ACCOUNT:
        log.error("Account mismatch! Expected #%s, got %s", ACCOUNT, getattr(acc, "login", "None"))
        mt5.shutdown()
        return False
    return True

def get_symbol_exposure(symbol: str) -> float:
    pos_vol = sum(float(p.volume) for p in (mt5.positions_get(symbol=symbol) or []))
    ord_vol = sum(float(o.volume_current) for o in (mt5.orders_get(symbol=symbol) or []))
    return round(pos_vol + ord_vol, 2)

def evaluate_and_deploy_brackets():
    if not init_mt5():
        return

    orders = mt5.orders_get() or []
    positions = mt5.positions_get() or []

    for sym, spec in ASSET_MATRIX.items():
        sym_info = mt5.symbol_info(sym)
        if not sym_info or not sym_info.visible:
            if not mt5.symbol_select(sym, True):
                continue
            sym_info = mt5.symbol_info(sym)

        point = sym_info.point
        digits = sym_info.digits
        ask = sym_info.ask
        bid = sym_info.bid

        # Check total active exposure
        curr_exp = get_symbol_exposure(sym)
        max_exp = float(spec["max_exposure"])
        base_lot = float(spec["lot"])

        if curr_exp + (base_lot * 2) > max_exp:
            continue  # Headroom saturated for this asset

        # Check existing pending orders for this symbol
        sym_orders = [o for o in orders if o.symbol == sym]
        if sym_orders:
            continue  # Already has active pending bracket

        # Calculate Bracket Pricing
        buf_pts = spec["buffer_points"] * point
        sl_pts = spec["sl_points"] * point
        tp_pts = (spec["be_tier2_points"] * 1.5) * point

        buy_price = round(ask + buf_pts, digits)
        buy_sl = round(buy_price - sl_pts, digits)
        buy_tp = round(buy_price + tp_pts, digits)

        sell_price = round(bid - buf_pts, digits)
        sell_sl = round(sell_price + sl_pts, digits)
        sell_tp = round(sell_price - tp_pts, digits)

        group_id = f"NX_{int(time.time())}_{sym}"

        # Place BUY_STOP
        buy_req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": sym,
            "volume": base_lot,
            "type": mt5.ORDER_TYPE_BUY_STOP,
            "price": buy_price,
            "sl": buy_sl,
            "tp": buy_tp,
            "deviation": 25,
            "magic": 999222,
            "comment": f"{group_id}_B",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC
        }
        res_b = mt5.order_send(buy_req)
        if not res_b or res_b.retcode != mt5.TRADE_RETCODE_DONE:
            log.warning("BUY_STOP failed for %s: %s", sym, getattr(res_b, "comment", "err"))
            continue

        # Place SELL_STOP
        sell_req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": sym,
            "volume": base_lot,
            "type": mt5.ORDER_TYPE_SELL_STOP,
            "price": sell_price,
            "sl": sell_sl,
            "tp": sell_tp,
            "deviation": 25,
            "magic": 999222,
            "comment": f"{group_id}_S",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC
        }
        res_s = mt5.order_send(sell_req)
        if not res_s or res_s.retcode != mt5.TRADE_RETCODE_DONE:
            log.warning("SELL_STOP failed for %s. Reverting paired BUY_STOP #%s", sym, res_b.order)
            mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": res_b.order})
            continue

        log.info("[BRACKET DEPLOYED] %s | Lots: %.2f | BuyStop: %.5f | SellStop: %.5f", sym, base_lot, buy_price, sell_price)

    mt5.shutdown()

if __name__ == "__main__":
    log.info("Starting Quant-Nexus Universal Multi-Straddle Single Evaluation...")
    evaluate_and_deploy_brackets()
    log.info("Evaluation complete.")