from pathlib import Path
import re

targets = [
    Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py"),
    Path(r"C:\Quant-Nexus-Prod\core\nexus_multi_straddle_daemon.py")
]

oco_method = """    def enforce_symbol_level_oco(self, max_active_symbols=4):
        positions = mt5.positions_get() or []
        orders = mt5.orders_get() or []
        
        active_symbols = {p.symbol for p in positions}
        for o in orders:
            if o.symbol in active_symbols and "NEXUS" in o.comment:
                res = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
                if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                    logging.info(f"[PER-SYMBOL OCO] Cancelled opposite pending leg #{o.ticket} on {o.symbol} (position already active).")
                    
        return len(active_symbols) >= max_active_symbols
"""

for target in targets:
    if not target.exists():
        continue
    content = target.read_text(encoding="utf-8", errors="ignore")
    
    content = re.sub(r"    def enforce_oco_brackets.*?return.*?\n", "", content, flags=re.DOTALL)
    content = re.sub(r"    def enforce_symbol_level_oco.*?return.*?\n", "", content, flags=re.DOTALL)
    content = content.replace("        self.enforce_oco_brackets()\n", "")
    content = content.replace("        self.enforce_symbol_level_oco()\n", "")
    
    content = content.replace("class DualGatedDynamicEngine:\n", f"class DualGatedDynamicEngine:\n{oco_method}\n")
    
    cycle_injection = """    def cycle(self):
        fleet_saturated = self.enforce_symbol_level_oco(max_active_symbols=4)
        if fleet_saturated:
            return
"""
    content = re.sub(r"    def cycle\(self\):\n.*?(?=for sym in SYMBOLS:)", cycle_injection + "        self.purge_stale_orders()\n        ", content, flags=re.DOTALL)

    target.write_text(content, encoding="utf-8")
    print(f"[+] Successfully deployed Per-Symbol OCO and 4-Asset Cap to {target.name}")