﻿$py = "C:\Program Files\Python312\python.exe"
$eng = "C:\Quant-Nexus-Eng"
$procs = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'"

# Supervise Terminal 1 (Magic 44044)
if (-not ($procs | Where-Object { $_.CommandLine -match "nexus_omega_apex_daemon\.py" -and $_.CommandLine -match "T1_QUANT" })) {
    Start-Process -FilePath $py `
        -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_Quant_278017866/terminal64.exe`" --magic 44044 --tag T1_QUANT" `
        -WorkingDirectory $eng -WindowStyle Hidden
}

# Supervise Terminal 3 (Magic 44045)
if (-not ($procs | Where-Object { $_.CommandLine -match "nexus_omega_apex_daemon\.py" -and $_.CommandLine -match "T3_HFT" })) {
    Start-Process -FilePath $py `
        -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_HFT_278041671/terminal64.exe`" --portable --magic 44045 --tag T3_HFT" `
        -WorkingDirectory $eng -WindowStyle Hidden
}
