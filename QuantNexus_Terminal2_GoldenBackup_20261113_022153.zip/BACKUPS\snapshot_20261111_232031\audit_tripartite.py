import MetaTrader5 as mt5

terminals = {
    "Quantower Majors (Quant Alert Bot)": (r"C:/MT5_Quant_278017866/terminal64.exe", 278017866),
    "Nexus AI Multi-Straddle":            (r"C:/MT5_Pending_278041169/terminal64.exe", 278041169),
    "Nexus 24/7 Gold HFT":                (r"C:/MT5_HFT_278041671/terminal64.exe", 278041671),
}

print("=" * 90)
print("TRIPARTITE MT5 TERMINAL & FLEET AUDIT")
print("=" * 90)

for name, (tpath, expected_login) in terminals.items():
    if mt5.initialize(path=tpath, portable=False):
        acc = mt5.account_info()
        pos = mt5.positions_get() or []
        orders = mt5.orders_get() or []
        status = "MATCH" if acc.login == expected_login else f"MISMATCH (Got #{acc.login})"
        print(f"[{status}] {name}")
        print(f"    Terminal : {tpath}")
        print(f"    Account  : #{acc.login} ({acc.server}) | Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f}")
        print(f"    Runners  : {len(pos)} open | Pending Brackets: {len(orders)}")
        mt5.shutdown()
    else:
        print(f"[-] Failed to initialize {name} via {tpath}: {mt5.last_error()}")
    print("-" * 90)