import pandas as pd
from pathlib import Path

p = Path(r"C:\Quant-Nexus-Eng\ml_data\BTCUSD_m5_features.parquet")
if p.exists():
    df = pd.read_parquet(p)
    cols = ["natr14", "atr_expansion_ratio", "garman_klass_vol", "rvol", "target_expansion"]
    print("=" * 85)
    print("       BTCUSD M5 FEATURE MATRIX (LATEST 5 ROWS)")
    print("=" * 85)
    print(df[cols].tail(5).to_string())
    print("=" * 85)
    print("SUMMARY STATS:")
    print(df[cols].describe().round(4).to_string())
    print("=" * 85)