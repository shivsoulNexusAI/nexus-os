﻿r"""
QuantNexus Asynchronous Telegram Telemetry & Remote Kill-Switch Module
Directory: C:\Quant-Nexus-Eng\telegram_alpha_bot.py
"""

import os
import sys
import json
import time
import logging
import asyncio
from pathlib import Path
from datetime import datetime, timezone
import httpx
import MetaTrader5 as mt5

CONFIG_FILE = Path(r"C:\Quant-Nexus-Eng\telegram_config.json")
KILL_SWITCH_FLAG = Path(r"C:\Quant-Nexus-Eng\emergency_halt.flag")
MT5_PATH = r"C:\MT5_Quant_278017866\terminal64.exe"
ACCOUNT = 278017866

log = logging.getLogger("TelegramAlphaBot")

def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        log.error("Failed to parse telegram config: %s", e)
        return {}

def send_telegram_alert_sync(message: str):
    """Synchronous fire-and-forget helper for critical execution events."""
    cfg = load_config()
    token = cfg.get("bot_token")
    chat_id = cfg.get("authorized_chat_id")
    if not token or not chat_id or "YOUR_" in token:
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML"
    }
    try:
        with httpx.Client(timeout=4.0) as client:
            client.post(url, json=payload)
    except Exception as e:
        log.warning("Telegram dispatch failed: %s", e)

async def emergency_flatten_positions():
    """Emergency protocol: Closes all open market orders on Account 278017866."""
    if not mt5.initialize(path=MT5_PATH):
        return "❌ MT5 connection failed during emergency flatten."
    
    acc = mt5.account_info()
    if not acc or acc.login != ACCOUNT:
        mt5.shutdown()
        return "❌ Account verification mismatch during liquidation."

    positions = mt5.positions_get()
    if not positions:
        mt5.shutdown()
        return "ℹ️ No open positions found on Account #278017866."

    closed_count = 0
    for p in positions:
        close_type = mt5.ORDER_TYPE_SELL if p.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(p.symbol).bid if close_type == mt5.ORDER_TYPE_SELL else mt5.symbol_info_tick(p.symbol).ask
        
        req = {
            "action": mt5.TRADE_ACTION_DEAL,
            "position": p.ticket,
            "symbol": p.symbol,
            "volume": p.volume,
            "type": close_type,
            "price": price,
            "deviation": 20,
            "magic": 278017866,
            "comment": "TELEGRAM_EMERGENCY_HALT",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        res = mt5.order_send(req)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            closed_count += 1

    mt5.shutdown()
    return f"🚨 <b>EMERGENCY LIQUIDATION COMPLETE:</b> Closed {closed_count}/{len(positions)} positions."

async def run_inbound_listener():
    """Long-polling listener for operator command overrides."""
    log.info("Starting Telegram Command Listener...")
    last_update_id = 0

    while True:
        cfg = load_config()
        token = cfg.get("bot_token")
        authorized_chat = str(cfg.get("authorized_chat_id"))

        if not token or not authorized_chat or "YOUR_" in token:
            await asyncio.sleep(10.0)
            continue

        url = f"https://api.telegram.org/bot{token}/getUpdates"
        params = {"offset": last_update_id + 1, "timeout": 15}

        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                resp = await client.get(url, params=params)
                if resp.status_code == 200:
                    data = resp.json()
                    for update in data.get("result", []):
                        last_update_id = update["update_id"]
                        msg = update.get("message", {})
                        chat_id = str(msg.get("chat", {}).get("id"))
                        text = msg.get("text", "").strip()

                        if chat_id != authorized_chat:
                            continue

                        # Command routing
                        if text == "/status":
                            status_msg = "🟢 <b>QuantNexus System Nominal</b>\nAccount: #278017866\nMode: LIVE-ARMED\nKill-Switch: "
                            status_msg += "🛑 ACTIVE (HALTED)" if KILL_SWITCH_FLAG.exists() else "✅ CLEAR (ARMED)"
                            send_telegram_alert_sync(status_msg)

                        elif text == "/emergency_halt":
                            KILL_SWITCH_FLAG.write_text(datetime.now(timezone.utc).isoformat())
                            flatten_report = await emergency_flatten_positions()
                            alert = f"🚨 <b>KILL-SWITCH TRIGGERED VIA TELEGRAM</b>\nDaemon halted immediately.\n{flatten_report}"
                            send_telegram_alert_sync(alert)

                        elif text == "/arm":
                            if KILL_SWITCH_FLAG.exists():
                                KILL_SWITCH_FLAG.unlink()
                            send_telegram_alert_sync("🟢 <b>QuantNexus Silver Bullet RE-ARMED.</b> Execution surveillance resumed.")

                        elif text == "/positions":
                            if not mt5.initialize(path=MT5_PATH):
                                send_telegram_alert_sync("❌ Terminal link error.")
                                continue
                            positions = mt5.positions_get()
                            mt5.shutdown()
                            if not positions:
                                send_telegram_alert_sync("📊 <b>Open Fleet Positions:</b> None.")
                            else:
                                pos_lines = [f"• {p.symbol} {'BUY' if p.type == 0 else 'SELL'} {p.volume} lots @ {p.price_open} | Profit: ${p.profit:.2f}" for p in positions]
                                send_telegram_alert_sync("📊 <b>Live Fleet Positions:</b>\n" + "\n".join(pos_lines))

        except Exception as e:
            await asyncio.sleep(5.0)

        await asyncio.sleep(2.0)

if __name__ == "__main__":
    asyncio.run(run_inbound_listener())