from pathlib import Path

p = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
code = p.read_text(encoding="utf-8")

old_fn = """    def read_microstructure(self, sym: str) -> dict:
        try:
            if MICRO_STATE_PATH.exists():
                data = json.loads(MICRO_STATE_PATH.read_text(encoding="utf-8"))
                return data.get("symbols", {}).get(sym, {})
        except Exception:
            pass
        return {}"""

new_fn = """    def read_microstructure(self, sym: str) -> dict:
        try:
            if MICRO_STATE_PATH.exists():
                data = json.loads(MICRO_STATE_PATH.read_text(encoding="utf-8"))
                fleet = data.get("fleet") or data.get("symbols") or data
                st = fleet.get(sym, {}) if isinstance(fleet, dict) else {}
                if isinstance(st, dict):
                    return {
                        "delta_pct": float(st.get("delta_pct", 0.0)),
                        "inside_poc_chop": bool(st.get("inside_poc_chop", False)),
                        "vpoc": float(st.get("vpoc", 0.0)),
                        "vah": float(st.get("vah", 0.0)),
                        "val": float(st.get("val", 0.0)),
                        "regime": str(st.get("regime", "UNKNOWN")),
                    }
        except Exception:
            pass
        return {}"""

assert old_fn in code, "old_fn not found"
p.write_text(code.replace(old_fn, new_fn, 1), encoding="utf-8")
print("[OK] Wired data['fleet'] into read_microstructure() in nexus_multi_straddle_daemon.py")