from pathlib import Path

# [DISABLED_V44] sb_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = sb_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING manage_open_trades AND scan_and_execute")
print("=" * 85)

def print_fn(name, max_lines=45):
    for idx, l in enumerate(lines):
        if f"def {name}" in l:
            print(f"\n--- {name} (Line {idx+1}) ---")
            for i in range(idx, min(len(lines), idx + max_lines)):
                print(f"{i+1:4d}: {lines[i]}")
            return

print_fn("manage_open_trades", 30)
print_fn("scan_and_execute", 50)
print("=" * 85)
