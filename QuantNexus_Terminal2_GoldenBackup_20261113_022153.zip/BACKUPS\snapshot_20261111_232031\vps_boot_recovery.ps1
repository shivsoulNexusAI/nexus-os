$py = "C:\Program Files\Python312\python.exe"
$mt5 = "C:\MT5_Quant_278017866\terminal64.exe"

# 1. Clean old >24h tick caches on boot
Get-ChildItem "C:\MT5_Quant_278017866\bases" -Recurse -Filter "*.tkc" -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-24) } |
    Remove-Item -Force -ErrorAction SilentlyContinue

# 2. Ensure MT5 terminal is running
if (-not (Get-Process -Name "terminal64" -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath $mt5
    Start-Sleep -Seconds 15
}

# 3. Launch ONLY the 5 clean V4.3 Final Production services
$services = @(
    "C:\Quant-Nexus-Eng\microstructure_sentinel.py",
    "C:\Quant-Nexus-Eng\breakeven_engine.py",
    "C:\Quant-Nexus-Eng\deal_resolution_watcher.py",
    "C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py",
    "C:\Quant-Nexus-Eng\telemetry_dashboard.py"
)

$running = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" | Select-Object -ExpandProperty CommandLine
foreach ($svc in $services) {
    $leaf = Split-Path $svc -Leaf
    if (-not ($running -match [regex]::Escape($leaf))) {
        Start-Process -FilePath $py -ArgumentList "-u", $svc -WorkingDirectory "C:\Quant-Nexus-Eng" -WindowStyle Hidden
        Start-Sleep -Seconds 2
    }
}