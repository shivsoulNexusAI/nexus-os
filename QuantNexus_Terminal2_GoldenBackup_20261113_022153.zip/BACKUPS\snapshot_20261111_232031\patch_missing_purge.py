from pathlib import Path
import py_compile
import re

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
content = path.read_text(encoding="utf-8", errors="ignore")

missing_methods = """    def purge_stale_orders(self, max_age_seconds=3600):
        orders = mt5.orders_get() or []
        now_ts = int(time.time())
        for o in orders:
            if "NEXUS" in o.comment:
                # Purge if order has been sitting longer than max_age_seconds
                order_age = now_ts - o.time_setup
                if order_age > max_age_seconds:
                    res = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
                    if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                        logging.info(f"[STALE PURGE] Removed pending order #{o.ticket} ({o.symbol}) after {order_age}s.")

    def enforce_symbol_level_oco(self, max_active_symbols=4):
        positions = mt5.positions_get() or []
        orders = mt5.orders_get() or []
        active_symbols = {p.symbol for p in positions}
        for o in orders:
            if o.symbol in active_symbols and "NEXUS" in o.comment:
                res = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
                if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                    logging.info(f"[PER-SYMBOL OCO] Cancelled opposite pending leg #{o.ticket} on {o.symbol} (trade active).")
        return len(active_symbols) >= max_active_symbols
"""

# Check if purge_stale_orders is defined; if not, inject it right after class definition
if "def purge_stale_orders" not in content:
    content = content.replace(
        "class DualGatedDynamicEngine:\n",
        f"class DualGatedDynamicEngine:\n{missing_methods}\n"
    )
    # Ensure enforce_symbol_level_oco isn't duplicated
    if content.count("def enforce_symbol_level_oco") > 1:
        # keep only the first
        first = content.find("def enforce_symbol_level_oco")
        second = content.find("def enforce_symbol_level_oco", first + 30)
        end_second = content.find("def ", second + 10)
        if end_second != -1:
            content = content[:second] + content[end_second:]

path.write_text(content, encoding="utf-8")

try:
    py_compile.compile(str(path), doraise=True)
    print("[+] Syntax validation PASSED: purge_stale_orders is properly integrated.")
except py_compile.PyCompileError as e:
    print(f"[-] Compilation error: {e}")