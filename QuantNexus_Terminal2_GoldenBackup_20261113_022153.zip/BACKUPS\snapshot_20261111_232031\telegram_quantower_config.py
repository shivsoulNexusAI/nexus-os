# -*- coding: utf-8 -*-
TELEGRAM_BOT_TOKEN = "8883861115:AAFAUqBcKSYjrIgo-Spoc5WuqSONeITx6Yw"
TELEGRAM_CHAT_ID = "5279761713"
TARGET_LOGIN = 278017866
TERMINAL_PATH = r"C:/Program Files/MetaTrader 5 - Apex Satellite/terminal64.exe"
