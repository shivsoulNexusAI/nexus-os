import time
import MetaTrader5 as mt5
from datetime import datetime

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
print("=" * 85)
print("ACCOUNT #278041169 LIVE EVENT STREAMER (Press Ctrl+C to Stop)")
print("=" * 85)

if mt5.initialize(path=TERMINAL, portable=False):
    known_pos = set()
    known_orders = set()
    
    try:
        while True:
            positions = mt5.positions_get() or []
            orders = mt5.orders_get() or []
            
            cur_pos = {p.ticket for p in positions}
            cur_ord = {o.ticket for o in orders}
            
            # Detect new position fill
            new_pos = cur_pos - known_pos
            for p in positions:
                if p.ticket in new_pos:
                    ptype = "BUY" if p.type == 0 else "SELL"
                    print(f"\a[{datetime.now().strftime('%H:%M:%S')}] [!] POSITION FILLED: #{p.ticket} | {p.symbol} {ptype} {p.volume:.2f}L @ {p.price_open:.5f} | SL: {p.sl:.5f}")
            
            # Detect closed/harvested position
            closed_pos = known_pos - cur_pos
            for c_ticket in closed_pos:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] [*] POSITION CLOSED/HARVESTED: #{c_ticket}")
                
            # Log pending count updates
            if len(cur_ord) != len(known_orders):
                print(f"[{datetime.now().strftime('%H:%M:%S')}] [i] Order Pool Updated: {len(cur_ord)} pending brackets active")
                
            known_pos = cur_pos
            known_orders = cur_ord
            time.sleep(3)
    except KeyboardInterrupt:
        print("\n[*] Sentinel stopped.")
    mt5.shutdown()
else:
    print("[-] MT5 Init failed.")