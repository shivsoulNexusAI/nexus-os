from pathlib import Path

for target in [Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py"), Path(r"C:\Quant-Nexus-Prod\core\nexus_multi_straddle_daemon.py")]:
    if not target.exists():
        continue
    content = target.read_text(encoding="utf-8", errors="ignore")
    
    # Calibrate decision threshold from 0.75 to 0.65
    content = content.replace('thresh = 0.75', 'thresh = 0.65')
    content = content.replace('thresh = self.model_bundle.get("decision_threshold", 0.75)', 'thresh = 0.65')
    
    target.write_text(content, encoding="utf-8")
    print(f"[+] Calibrated threshold to 0.65 in {target.name}")