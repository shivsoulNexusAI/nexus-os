import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
ASSETS = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "BTCUSD"]

if mt5.initialize(path=TERMINAL, portable=False, timeout=10000):
    acc = mt5.account_info()
    print("=" * 85)
    print(f"TERMINAL ASSET SPECIFICATIONS: ACCOUNT #{acc.login} ({acc.server})")
    print(f"Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f}")
    print("=" * 85)
    
    for sym in ASSETS:
        mt5.symbol_select(sym, True)
        info = mt5.symbol_info(sym)
        tick = mt5.symbol_info_tick(sym)
        if info and tick:
            spread = (tick.ask - tick.bid)
            spread_pts = spread / info.point
            print(f"{sym:<7} | Digits: {info.digits} | Point: {info.point:.5f} | StopsLevel: {info.trade_stops_level:3d} pts | Spread: {spread_pts:4.1f} pts (${spread:.4f})")
        else:
            print(f"[-] {sym}: Could not retrieve symbol/tick info.")
            
    mt5.shutdown()
    print("=" * 85)
else:
    print("[-] MT5 initialization failed.")