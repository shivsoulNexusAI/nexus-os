from pathlib import Path

# [DISABLED_V44] script_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = script_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 80)
print("INSPECTING route_silver_bullet_order FUNCTION DEFINITION")
print("=" * 80)

found = False
for idx, line in enumerate(lines):
    if "def route_silver_bullet_order" in line:
        found = True
        for i in range(idx, min(len(lines), idx + 45)):
            print(f"{i+1:4d}: {lines[i]}")
        break

if not found:
    print("[-] Function definition not found directly under that name.")
print("=" * 80)
