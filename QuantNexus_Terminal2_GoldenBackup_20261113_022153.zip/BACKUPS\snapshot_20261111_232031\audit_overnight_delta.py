# -*- coding: utf-8 -*-
"""
QUANT-NEXUS OVERNIGHT ROLLOVER & TRIPLE-BOT DEEP DELTA AUDIT
Audits:
1. Last night's rollover (swap, financing costs, closed deals since 20:00 UTC yesterday).
2. Live running positions, pending orders, and mark-to-market floating equity.
3. VPS daemon health (PIDs, memory, uptime, headless status).
4. Telegram telemetry connection state.
"""
import os
import sys
import psutil
from datetime import datetime, timezone, timedelta
import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"

print("=" * 90)
print(f"      QUANT-NEXUS MULTI-BOT DEEP DELTA AUDIT [{datetime.now(timezone.utc):%Y-%m-%d %H:%M:%S} UTC]")
print("=" * 90)

# 1. Terminal & Account Telemetry
if not mt5.initialize(path=TERMINAL, portable=False):
    print(f"[-] MT5 Terminal Initialization Failed: {mt5.last_error()}")
    sys.exit(1)

acc = mt5.account_info()
print(f"PRIMARY ACCOUNT      : #{acc.login} ({acc.server})")
print(f"Account Balance      : ${acc.balance:,.2f}")
print(f"Account Equity       : ${acc.equity:,.2f}")
print(f"Floating PnL         : ${acc.profit:+,.2f}")
print(f"Margin Free / Level  : ${acc.margin_free:,.2f} ({acc.margin_level:.1f}%)")
print("-" * 90)

# 2. Rollover & Swap Audit (Since 20:00 UTC yesterday)
rollover_cutoff = datetime.now(timezone.utc) - timedelta(hours=14)
deals = mt5.history_deals_get(rollover_cutoff, datetime.now(timezone.utc)) or []

total_swap = 0.0
total_commission = 0.0
total_realized = 0.0
closed_deals = [d for d in deals if d.entry == 1]

print("OVERNIGHT ROLLOVER & CLOSED DEALS (LAST 14 HOURS):")
if closed_deals:
    print(f"{'DEAL #':<12} | {'SYMBOL':<8} | {'TYPE':<6} | {'LOTS':<5} | {'EXIT':<10} | {'SWAP':<7} | {'PROFIT':<8} | {'COMMENT'}")
    print("-" * 90)
    for d in closed_deals:
        d_type = "BUY" if d.type == 0 else "SELL"
        total_swap += d.swap
        total_commission += d.commission
        total_realized += d.profit
        print(f"#{d.ticket:<11} | {d.symbol:<8} | {d_type:<6} | {d.volume:<5.2f} | {d.price:<10.5f} | ${d.swap:<6.2f} | ${d.profit:>+7.2f} | {d.comment}")
else:
    print("  -> No deals closed overnight during rollover window.")

print(f"\nRollover Net Realized: ${total_realized:+,.2f} | Overnight Swaps: ${total_swap:+,.2f} | Commission: ${total_commission:,.2f}")
print("-" * 90)

# 3. Active Positions (Current Fleet)
positions = mt5.positions_get() or []
print(f"ACTIVE RUNNERS IN PLAY ({len(positions)}):")
if positions:
    for p in positions:
        side = "BUY" if p.type == 0 else "SELL"
        pts = (p.price_current - p.price_open) if side == "BUY" else (p.price_open - p.price_current)
        print(f"  -> POS #{p.ticket:<10} | {p.symbol:<7} {side} {p.volume:.2f}L | Entry: {p.price_open:.5f} | Mark: {p.price_current:.5f} | Move: {pts:>+8.2f} | SL: {p.sl:.5f} | Swap: ${p.swap:+.2f} | Floating: ${p.profit:>+6.2f}")
else:
    print("  -> Fleet flat (all runners banked or stopped in profit).")

# 4. Pending Orders
orders = mt5.orders_get() or []
print(f"\nPENDING BRACKET ORDERS ({len(orders)}):")
for o in orders:
    t = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
    print(f"  -> ORD #{o.ticket:<10} | {o.symbol:<7} {t:<9} {o.volume_current:.2f}L | Price: {o.price_open:.5f} | SL: {o.sl:.5f} | TP: {o.tp:.5f} | Comment: {o.comment}")

mt5.shutdown()
print("=" * 90)