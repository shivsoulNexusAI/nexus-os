from pathlib import Path
import re

gold_script = Path("C:/Quant-Nexus-Eng/gold_hft_straddle_daemon.py")
content = gold_script.read_text(encoding="utf-8", errors="ignore")

# 1. Update terminal path to dedicated HFT instance
content = re.sub(
    r'path\s*=\s*r?["\'].*?terminal64\.exe["\']',
    r'path=r"C:/MT5_HFT_278041671/terminal64.exe"',
    content
)

# 2. Bind to gold telegram config if telegram_config is imported
if "telegram_gold_config" not in content and "telegram_config" in content:
    content = content.replace("from telegram_config import", "from telegram_gold_config import")
    content = content.replace("import telegram_config", "import telegram_gold_config as telegram_config")

gold_script.write_text(content, encoding="utf-8")
print("[+] gold_hft_straddle_daemon.py successfully bound to C:/MT5_HFT_278041671/terminal64.exe")