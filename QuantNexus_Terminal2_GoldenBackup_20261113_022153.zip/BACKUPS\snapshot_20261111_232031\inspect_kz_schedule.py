from pathlib import Path
import time

# 1. Print check_killzone() code definition
# [DISABLED_V44] sb_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.py")
lines = sb_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
# [DISABLED_V44] print("ICT KILLZONE WINDOW SCHEDULE IN silver_bullet_daemon.py")
print("=" * 85)
for idx, line in enumerate(lines):
    if "def check_killzone" in line:
        for i in range(idx, min(len(lines), idx + 25)):
            print(f"{i+1:4d}: {lines[i]}")
        break

# 2. Tail the latest log output to confirm PID 980 is actively emitting heartbeats
print("-" * 85)
print("LIVE DAEMON LOG STREAM (PID 980):")
# [DISABLED_V44] log_path = Path(r"C:\Quant-Nexus-Eng\silver_bullet_daemon.log")
if log_path.exists():
    for l in log_path.read_text(encoding="utf-8", errors="ignore").splitlines()[-15:]:
        print(f"  {l}")
print("=" * 85)
