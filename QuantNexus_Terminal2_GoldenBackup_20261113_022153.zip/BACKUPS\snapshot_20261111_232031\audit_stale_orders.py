import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    exit(1)

orders = mt5.orders_get() or []
print("=" * 85)
print(f"STALE PENDING ORDERS AUDIT ON ACCOUNT #{mt5.account_info().login}")
print("=" * 85)

for o in orders:
    t = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
    age_hours = (mt5.symbol_info_tick(o.symbol).time - o.time_setup) / 3600 if o.time_setup else 0
    print(f"Order #{o.ticket} | {o.symbol:<7} {t:<9} {o.volume_current:.2f}L | Open Price: {o.price_open:.5f} | Comment: {o.comment}")
mt5.shutdown()
print("=" * 85)