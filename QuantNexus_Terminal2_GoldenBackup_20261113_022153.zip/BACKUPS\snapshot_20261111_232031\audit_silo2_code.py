from pathlib import Path

files_to_check = [
    Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py"),
    Path(r"C:\Quant-Nexus-Prod\core\breakeven_engine.py"),
    Path(r"C:\Quant-Nexus-Prod\core\nexus_multi_straddle_daemon.py")
]

print("=" * 85)
print("AUDITING ENGINE ARCHITECTURE FOR ACCOUNT #278041169")
print("=" * 85)

for f in files_to_check:
    if f.exists():
        print(f"\n[+] FILE IDENTIFIED: {f}")
        lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()
        print(f"    Total Lines: {len(lines)}")
        for idx, l in enumerate(lines[:45]):
            if any(k in l for k in ["ACCOUNT", "SYMBOL", "TP", "SL", "1.80", "trailing", "harvest", "MAGIC"]):
                print(f"    {idx+1:3d}: {l.strip()}")
    else:
        print(f"[-] Missing: {f}")
print("=" * 85)