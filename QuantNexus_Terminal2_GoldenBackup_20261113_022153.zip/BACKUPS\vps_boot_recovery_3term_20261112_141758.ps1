﻿$py = "C:\Program Files\Python312\python.exe"
$eng = "C:\Quant-Nexus-Eng"

# 1. Clean old >24h tick caches on boot
Get-ChildItem "C:\MT5_Quant_278017866\bases" -Recurse -Filter "*.tkc" -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-24) } |
    Remove-Item -Force -ErrorAction SilentlyContinue

# 2. Ensure Terminal 1 (MT5_Quant_278017866) & Terminal 3 (MT5_HFT_278041671 /portable) are running
$procs = Get-CimInstance Win32_Process -Filter "Name = 'terminal64.exe'"
if (-not ($procs | Where-Object { $_.ExecutablePath -match "MT5_Quant_278017866" })) {
    Start-Process -FilePath "C:\MT5_Quant_278017866\terminal64.exe"
    Start-Sleep -Seconds 12
}
if (-not ($procs | Where-Object { $_.ExecutablePath -match "MT5_HFT_278041671" })) {
    Start-Process -FilePath "C:\MT5_HFT_278041671\terminal64.exe" -ArgumentList "/portable"
    Start-Sleep -Seconds 12
}

# 3. Launch ONLY Final Production v44.2 services (zero legacy Magic=0 daemons)
$pyProcs = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" | Select-Object -ExpandProperty CommandLine

if (-not ($pyProcs -match "microstructure_sentinel\.py")) {
    Start-Process -FilePath $py -ArgumentList "-u", "$eng\microstructure_sentinel.py" -WorkingDirectory $eng -WindowStyle Hidden
}
if (-not ($pyProcs -match "nexus_omega_apex_daemon\.py.*T1_QUANT")) {
    Start-Process -FilePath $py -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_Quant_278017866/terminal64.exe`" --magic 44044 --tag T1_QUANT" -WorkingDirectory $eng -WindowStyle Hidden
}
if (-not ($pyProcs -match "nexus_omega_apex_daemon\.py.*T3_HFT")) {
    Start-Process -FilePath $py -ArgumentList "$eng\nexus_omega_apex_daemon.py --terminal `"C:/MT5_HFT_278041671/terminal64.exe`" --portable --magic 44045 --tag T3_HFT" -WorkingDirectory $eng -WindowStyle Hidden
}
