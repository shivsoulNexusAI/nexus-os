import MetaTrader5 as mt5
from datetime import datetime, timezone

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False):
    acc = mt5.account_info()
    orders = mt5.orders_get() or []
    positions = mt5.positions_get() or []
    
    print("=" * 95)
    print(f"ACCOUNT #{acc.login} FULL PRODUCTION SPECIFICATION AUDIT")
    print(f"Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f} | Free Margin: ${acc.margin_free:,.2f}")
    print("=" * 95)
    print(f"Active Positions: {len(positions)} | Working Orders: {len(orders)}\n")
    
    header = f"{'Ticket':<11} | {'Symbol':<7} | {'Type':<9} | {'Vol':<5} | {'Price':<11} | {'SL':<11} | {'TP':<11} | {'Expiry (UTC)'}"
    print(header)
    print("-" * len(header))
    
    for o in sorted(orders, key=lambda x: x.symbol):
        ot = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
        exp_str = datetime.fromtimestamp(o.time_expiration, tz=timezone.utc).strftime('%H:%M:%S UTC') if o.time_expiration > 0 else "GTC"
        print(f"#{o.ticket:<10} | {o.symbol:<7} | {ot:<9} | {o.volume_current:4.2f}L | {o.price_open:<11.5f} | {o.sl:<11.5f} | {o.tp:<11.5f} | {exp_str}")
        
    mt5.shutdown()
    print("=" * 95)