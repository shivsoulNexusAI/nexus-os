from pathlib import Path

gold_path = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py")
lines = gold_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING GOLD HFT STRADDLE BRACKET MANAGEMENT (LINES 194-250)")
print("=" * 85)
for i in range(193, min(len(lines), 250)):
    print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)