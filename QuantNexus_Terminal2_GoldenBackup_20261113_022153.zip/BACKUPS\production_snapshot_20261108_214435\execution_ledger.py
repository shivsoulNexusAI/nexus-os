import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(r"C:\Quant-Nexus-Eng\execution_ledger.db")

def init_ledger():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS execution_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                direction TEXT NOT NULL,
                killzone TEXT NOT NULL,
                requested_volume REAL NOT NULL,
                target_price REAL NOT NULL,
                fill_price REAL NOT NULL,
                slippage_pts REAL NOT NULL,
                spread_pts REAL NOT NULL,
                signal_timestamp TEXT NOT NULL,
                dispatch_latency_ms REAL NOT NULL,
                broker_ack_latency_ms REAL NOT NULL,
                magic INTEGER NOT NULL,
                retcode INTEGER NOT NULL,
                broker_comment TEXT
            );
        """)
        conn.commit()

def record_execution(ticket, symbol, direction, killzone, volume,
                     target_price, fill_price, point_size, spread_pts,
                     signal_time, dispatch_latency_ms, broker_ack_latency_ms,
                     magic=278017866, retcode=10009, broker_comment=""):
    init_ledger()
    slippage_pts = (fill_price - target_price) / point_size if point_size > 0 else 0.0
    if direction == "SELL":
        slippage_pts = -slippage_pts

    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO execution_events (
                ticket, symbol, direction, killzone, requested_volume,
                target_price, fill_price, slippage_pts, spread_pts,
                signal_timestamp, dispatch_latency_ms, broker_ack_latency_ms,
                magic, retcode, broker_comment
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ticket, symbol, direction, killzone, volume,
            target_price, fill_price, round(slippage_pts, 2), round(spread_pts, 2),
            signal_time.isoformat(), round(dispatch_latency_ms, 2), round(broker_ack_latency_ms, 2),
            magic, retcode, broker_comment
        ))
        conn.commit()

if __name__ == "__main__":
    init_ledger()
    print("[+] Initialized SQLite execution ledger.")