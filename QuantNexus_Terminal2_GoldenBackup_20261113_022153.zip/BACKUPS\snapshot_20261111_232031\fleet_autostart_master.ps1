﻿# ==============================================================================
# QUANTNEXUS MASTER AUTO-START FLEET LAUNCHER
# Executed on Windows Boot / Scheduled Task
# ==============================================================================
$ErrorActionPreference = "Continue"
Set-Location "C:\Quant-Nexus-Eng"

$py = "C:\Program Files\Python312\python.exe"
$logFile = "C:\Quant-Nexus-Eng\fleet_autostart.log"

function Write-BootLog ($msg) {
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    "[$timestamp] $msg" | Out-File -FilePath $logFile -Append -Encoding utf8
    Write-Host "[$timestamp] $msg"
}

Write-BootLog "=========================================================="
Write-BootLog "INITIATING QUANTNEXUS TRI-TERMINAL AUTO-BOOT SEQUENCE"
Write-BootLog "=========================================================="

# 1. Terminate any lingering orphaned processes cleanly
# [DISABLED_V44] Get-CimInstance Win32_Process -Filter "CommandLine LIKE '%silver_bullet_daemon%' OR CommandLine LIKE '%gold_hft_straddle_daemon%' OR CommandLine LIKE '%pending_majors_daemon%' OR CommandLine LIKE '%engine_watchdog%'" |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

Start-Sleep -Seconds 2

# 2. Boot MT5 Terminals in Sequence
$terminals = @(
    @{ Name = "SilverBullet_278017866"; Path = "C:\MT5_Quant_278017866\terminal64.exe" },
    @{ Name = "PendingMajors_278041169"; Path = "C:\MT5_Pending_278041169\terminal64.exe" },
    @{ Name = "GoldHFT_278041671"; Path = "C:\MT5_HFT_278041671\terminal64.exe" }
)

foreach ($t in $terminals) {
    if (Test-Path $t.Path) {
        $running = Get-Process -Name "terminal64" -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $t.Path }
        if (-not $running) {
            Write-BootLog "Launching Terminal: $($t.Name)..."
            Start-Process -FilePath $t.Path -WindowStyle Minimized
            Start-Sleep -Seconds 4
        } else {
            Write-BootLog "Terminal $($t.Name) already running."
        }
    } else {
        Write-BootLog "[-] ERROR: Terminal executable not found at $($t.Path)"
    }
}

Write-BootLog "MT5 Terminals loaded. Waiting 5s for IPC endpoints to bind..."
Start-Sleep -Seconds 5

# 3. Launch Daemon 1: Silver Bullet Sniper (#278017866 -> @Qunatalertbot)
# [DISABLED_V44] Write-BootLog "Starting silver_bullet_daemon.py..."
Start-Process -FilePath $py `
    -ArgumentList "-u quantum_institutional_pro.py" `
    -WorkingDirectory "C:\Quant-Nexus-Eng" `
    -RedirectStandardOutput "C:\Quant-Nexus-Eng\silver_bullet.log" `
    -RedirectStandardError "C:\Quant-Nexus-Eng\silver_bullet_err.log" `
    -WindowStyle Hidden

Start-Sleep -Seconds 2

# 4. Launch Daemon 2: 4 Majors & Indices Pending Grid (#278041169 -> @Nexus_AIk_bot)
Write-BootLog "Starting pending_majors_daemon.py..."
Start-Process -FilePath $py `
    -ArgumentList "-u pending_majors_daemon.py" `
    -WorkingDirectory "C:\Quant-Nexus-Eng" `
    -RedirectStandardOutput "C:\Quant-Nexus-Eng\pending_majors_telemetry.log" `
    -RedirectStandardError "C:\Quant-Nexus-Eng\pending_majors_telemetry_err.log" `
    -WindowStyle Hidden

Start-Sleep -Seconds 2

# 5. Launch Daemon 3: Gold 24/7 HFT Straddle (#278041671 -> @Nexus_Gold 24/7)
Write-BootLog "Starting gold_hft_straddle_daemon.py..."
Start-Process -FilePath $py `
    -ArgumentList "-u gold_hft_straddle_daemon.py" `
    -WorkingDirectory "C:\Quant-Nexus-Eng" `
    -RedirectStandardOutput "C:\Quant-Nexus-Eng\gold_hft_straddle.log" `
    -RedirectStandardError "C:\Quant-Nexus-Eng\gold_hft_straddle_err.log" `
    -WindowStyle Hidden

Start-Sleep -Seconds 2

# 6. Launch Engine Watchdog Sentinel
if (Test-Path "C:\Quant-Nexus-Eng\engine_watchdog.ps1") {
    Write-BootLog "Starting engine_watchdog.ps1..."
    Start-Process -FilePath "powershell.exe" `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File C:\Quant-Nexus-Eng\engine_watchdog.ps1" `
        -WorkingDirectory "C:\Quant-Nexus-Eng" `
        -WindowStyle Hidden
}

Write-BootLog "=========================================================="
Write-BootLog "FLEET ONLINE: ALL THREE ENGINES AND TELEMETRY ACTIVE"
Write-BootLog "=========================================================="
