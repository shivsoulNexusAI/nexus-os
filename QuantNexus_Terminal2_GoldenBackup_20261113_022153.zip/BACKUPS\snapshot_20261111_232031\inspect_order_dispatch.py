from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING LINES 174-215 OF nexus_multi_straddle_daemon.py")
print("=" * 85)
for i in range(173, min(len(lines), 215)):
    print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)