from pathlib import Path
p = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
txt = p.read_text(encoding="utf-8")
old = "now_ts = int(time.time())"
new = "ref_tick = mt5.symbol_info_tick('EURUSD'); now_ts = int(ref_tick.time) if ref_tick else int(time.time())"
if old in txt:
    txt = txt.replace(old, new, 1)
    txt = txt.replace("(now_ts - d.time) <= 3600", "0 <= (now_ts - d.time) <= 3600", 1)
    p.write_text(txt, encoding="utf-8")
    print("[OK] Aligned AntiWhipsaw clock to MT5 broker server time.")