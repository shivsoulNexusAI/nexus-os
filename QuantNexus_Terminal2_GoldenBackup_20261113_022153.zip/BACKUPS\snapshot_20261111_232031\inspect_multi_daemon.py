from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
if not path.exists():
    path = Path(r"C:\Quant-Nexus-Prod\core\nexus_multi_straddle_daemon.py")

lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print(f"INSPECTING STRADDLE LOGIC: {path.name} ({len(lines)} lines)")
print("=" * 85)

# Find key sections
for idx, l in enumerate(lines):
    if any(k in l for k in ["ASSETS", "CONFIG", "def place_straddle", "def sync_brackets", "def manage_positions"]):
        print(f"\n--- Section around line {idx+1}: {l.strip()} ---")
        for i in range(idx, min(len(lines), idx + 30)):
            print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)