import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_HFT_278041671/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False, timeout=10000):
    acc = mt5.account_info()
    pos = mt5.positions_get() or []
    orders = mt5.orders_get() or []
    print("=" * 80)
    print(f"NEXUS GOLD 24/7 LIVE FLEET AUDIT (ACCOUNT #{acc.login})")
    print(f"Balance: ${acc.balance:,.2f} | Equity: ${acc.equity:,.2f}")
    print(f"Active Positions: {len(pos)} | Pending Brackets: {len(orders)}")
    for o in orders:
        t = "BUY_STOP" if o.type == 4 else ("SELL_STOP" if o.type == 5 else str(o.type))
        print(f"  -> Order #{o.ticket} | {o.symbol} {t} {o.volume_current:.2f}L @ {o.price_open:.2f} | SL: {o.sl:.2f} | TP: {o.tp:.2f} | Comment: {o.comment}")
    mt5.shutdown()
    print("=" * 80)
else:
    print(f"[-] Init failed: {mt5.last_error()}")