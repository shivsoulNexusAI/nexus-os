from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
if not path.exists():
    path = Path(r"C:\Quant-Nexus-Prod\core\nexus_multi_straddle_daemon.py")

content = path.read_text(encoding="utf-8", errors="ignore")

# Enforce a 60-minute order cancellation loop for straddle orders
old_sync = "def sync_brackets("
new_sync = """def purge_stale_brackets(max_age_seconds=3600):
    import time
    orders = mt5.orders_get() or []
    now = time.time()
    for o in orders:
        if "NEXUS_DYN" in o.comment or "STRAD" in o.comment:
            if (now - o.time_setup) > max_age_seconds:
                mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})

def sync_brackets("""

if "purge_stale_brackets" not in content and old_sync in content:
    content = content.replace(old_sync, new_sync)
    path.write_text(content, encoding="utf-8")
    print("[+] Successfully integrated automated 60-minute TTL bracket purge.")
else:
    print("[i] TTL purge already present or hook pattern not found.")