import MetaTrader5 as mt5
from datetime import datetime, timezone, timedelta

TERMINAL = r"C:/MT5_Quant_278017866/terminal64.exe"
if not mt5.initialize(path=TERMINAL, portable=False):
    print("[-] MT5 Init failed")
    exit(1)

from_d = datetime.now(timezone.utc) - timedelta(hours=6)
deals = mt5.history_deals_get(from_d, datetime.now(timezone.utc)) or []

print("=" * 110)
print("             VERIFIED CLOSED DEALS AUDIT (REALIZED NUMBERS)")
print("=" * 110)
print("{:<12} | {:<7} | {:<5} | {:<10} | {:<11} | {:<7} | {}".format("DEAL", "SYMBOL", "LOTS", "PRICE", "NET PNL", "FEE", "COMMENT"))
print("-" * 110)

tot_pnl = 0.0
tot_fee = 0.0
for d in deals:
    if d.entry == 1:  # Out / Close deals
        p = float(d.profit)
        c = float(d.commission)
        tot_pnl += p
        tot_fee += c
        print("{:<12} | {:<7} | {:<5.2f} | {:<10.5f} | ${:>+9.2f} | ${:>5.2f} | {}".format(d.ticket, d.symbol, d.volume, d.price, p, c, d.comment))

print("=" * 110)
print("TOTAL REALIZED GROSS PROFIT : ${:>+10.2f}".format(tot_pnl))
print("TOTAL BROKER COMMISSIONS    : ${:>10.2f}".format(tot_fee))
print("NET CASH REALIZED TO SILO 2 : ${:>+10.2f}".format(tot_pnl + tot_fee))
print("=" * 110)

# Check active fleet positions
positions = mt5.positions_get() or []
print("\nACTIVE RUNNERS ({} OPEN):".format(len(positions)))
for pos in positions:
    side = "BUY" if pos.type == 0 else "SELL"
    print("  -> #{:<10} {:<7} {} {:<4.2f} lots @ {:<10.5f} | Mark: {:<10.5f} | PnL: ${:>+7.2f} | SL: {}".format(
        pos.ticket, pos.symbol, side, pos.volume, pos.price_open, pos.price_current, pos.profit, pos.sl
    ))

mt5.shutdown()