# -*- coding: utf-8 -*-

# --- ROLLOVER LIQUIDITY SHIELD (Injected v2.4) ---
from datetime import datetime, timezone
def is_liquidity_gap_active():
    utc_hour = datetime.now(timezone.utc).hour
    utc_min = datetime.now(timezone.utc).minute
    # Block new brackets between 21:55 UTC and 01:15 UTC (Spread expansion hours)
    if utc_hour == 21 and utc_min >= 55: return True
    if utc_hour in [22, 23, 0]: return True
    if utc_hour == 1 and utc_min <= 15: return True
    return False
"""
QuantNexus Mission Charlie: T3 Gold HFT Volatility & ATR Band Adaptation
Terminal 3 (#278041671) - Dynamic ATR & Choppiness Filter
Suppresses straddle order placement during low-liquidity chop / Asian consolidation.
"""
import sys
import os

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

import time
import math
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
import httpx
import MetaTrader5 as mt5

CONFIG_FILE = Path(r"C:\Quant-Nexus-Eng\t3_telegram_config.json")
LOG_FILE = Path(r"C:\Quant-Nexus-Eng\gold_hft.log")
STATE_FILE = Path(r"C:\Quant-Nexus-Eng\gold_volatility_state.json")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE), encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger("GoldHFT")

TERMINAL_PATH = r"C:\MT5_HFT_278041671\terminal64.exe"
ACCOUNT_ID = 278041671
SYMBOL = "XAUUSD"
MAGIC_NUMBER = 777001

# Volatility Thresholds
ATR_PERIOD = 14
MIN_ATR_NORMAL = 1.80      # Min $1.80 M5 range required
MIN_ATR_ASIAN = 2.40       # Stricter $2.40 M5 range required during Asian session
CHOP_THRESHOLD = 55.0         # Tighter chop filter (blocks quiet consolidation)      # CHOP >= 61.8 indicates consolidation chop (freeze straddle)
STRADDLE_OFFSET_POINTS = 1500  # $1.50 dynamic breakout buffer # 15 pips ($1.50)
SL_POINTS = 2000              # $2.00 stop loss (prevents spread chop)              # 12 pips ($1.20)
TP_POINTS = 4500              # $4.50 target expansion (1:2.25 RR)              # 30 pips ($3.00)
LOT_SIZE = 0.01

def load_telegram_cfg():
    if not CONFIG_FILE.exists():
        return None, None
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return data.get("bot_token"), data.get("authorized_chat_id")
    except Exception:
        return None, None

def send_alert(msg: str):
    token, chat_id = load_telegram_cfg()
    if not token or not chat_id:
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        with httpx.Client(timeout=8.0) as client:
            client.post(url, json={"chat_id": chat_id, "text": msg, "parse_mode": "HTML"})
    except Exception as e:
        log.warning("Telegram dispatch error: %s", e)

def get_filling_type(symbol: str) -> int:
    sym_info = mt5.symbol_info(symbol)
    if not sym_info:
        return mt5.ORDER_FILLING_IOC
    modes = sym_info.filling_mode
    if modes & 1:
        return mt5.ORDER_FILLING_FOK
    elif modes & 2:
        return mt5.ORDER_FILLING_IOC
    return mt5.ORDER_FILLING_RETURN

def calculate_atr_and_chop(rates):
    """Calculates ATR(14) and Choppiness Index(14) from M5 candle array."""
    if rates is None or len(rates) < ATR_PERIOD + 2:
        return 0.0, 100.0

    trs = []
    for i in range(1, len(rates)):
        high = rates[i]['high']
        low = rates[i]['low']
        prev_close = rates[i - 1]['close']
        tr = max(high - low, abs(high - prev_close), abs(low - prev_close))
        trs.append(tr)

    # Rolling 14 ATR
    atr = sum(trs[-ATR_PERIOD:]) / ATR_PERIOD

    # Choppiness Index (14)
    sum_tr = sum(trs[-ATR_PERIOD:])
    highest_high = max(r['high'] for r in rates[-ATR_PERIOD:])
    lowest_low = min(r['low'] for r in rates[-ATR_PERIOD:])
    price_span = highest_high - lowest_low

    if price_span <= 0:
        chop = 100.0
    else:
        chop = 100.0 * (math.log10(sum_tr / price_span) / math.log10(ATR_PERIOD))

    return round(atr, 2), round(chop, 1)

def purge_pending_orders():
    """Cancels any lingering straddle stop orders when volatility collapses."""
    orders = mt5.orders_get(symbol=SYMBOL) or []
    purged = 0
    for o in orders:
        if o.magic == MAGIC_NUMBER:
            req = {"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket}
            res = mt5.order_send(req)
            if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                purged += 1
    if purged > 0:
        log.info("Purged %d stale Gold straddle orders due to low volatility chop.", purged)

def sync_gold_straddle():
    mt5.symbol_select(SYMBOL, True)
    rates = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M5, 0, 30)
    if rates is None or len(rates) == 0:
        # Check suffix variant (e.g. XAUUSDm on Exness Standard)
        for alt in [SYMBOL + "m", "XAUUSDm", "GOLD"]:
            if mt5.symbol_select(alt, True):
                rates = mt5.copy_rates_from_pos(alt, mt5.TIMEFRAME_M5, 0, 30)
                if rates is not None and len(rates) > 0:
                    break
    atr, chop = calculate_atr_and_chop(rates)

    now_utc = datetime.now(timezone.utc)
    is_asian = (now_utc.hour >= 22 or now_utc.hour < 6)
    min_atr_required = MIN_ATR_ASIAN if is_asian else MIN_ATR_NORMAL

    # Volatility Check
    is_volatile_enough = (atr >= min_atr_required)
    is_trending_flow = (chop < CHOP_THRESHOLD)
    straddle_permitted = is_volatile_enough and is_trending_flow

    # Write status to state file
    state = {
        "timestamp": now_utc.isoformat(),
        "symbol": SYMBOL,
        "atr_m5": atr,
        "min_atr_required": min_atr_required,
        "chop_index": chop,
        "is_asian_session": is_asian,
        "straddle_permitted": straddle_permitted,
        "status": "ARMED" if straddle_permitted else f"CHOP LOCKOUT (ATR: {atr} | CHOP: {chop})"
    }
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")

    # If active positions already exist, don't interfere with running trade
    positions = [p for p in (mt5.positions_get(symbol=SYMBOL) or []) if p.magic == MAGIC_NUMBER]
    if positions:
        log.debug("Active Gold position running (#%d). Straddle hold.", positions[0].ticket)
        return

    # If suppressed due to chop, purge any pending stops and exit
    if not straddle_permitted:
        purge_pending_orders()
        log.info("Gold Straddle Halted: ATR $%.2f < $%.2f or CHOP %.1f >= %.1f", 
                 atr, min_atr_required, chop, CHOP_THRESHOLD)
        return

    # Maintain buy-stop and sell-stop bracket
    tick = mt5.symbol_info_tick(SYMBOL)
    sym_info = mt5.symbol_info(SYMBOL)
    if not tick or not sym_info:
        return

    point = sym_info.point
    filling = get_filling_type(SYMBOL)
    orders = [o for o in (mt5.orders_get(symbol=SYMBOL) or []) if o.magic == MAGIC_NUMBER]

    buy_stops = [o for o in orders if o.type == mt5.ORDER_TYPE_BUY_STOP]
    sell_stops = [o for o in orders if o.type == mt5.ORDER_TYPE_SELL_STOP]

    digits = sym_info.digits
    target_buy_price = round(tick.ask + (STRADDLE_OFFSET_POINTS * point), digits)
    target_sell_price = round(tick.bid - (STRADDLE_OFFSET_POINTS * point), digits)

    # Re-center Buy Stop if displaced > 10 pips
    if not buy_stops:
        req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": SYMBOL,
            "volume": LOT_SIZE,
            "type": mt5.ORDER_TYPE_BUY_STOP,
            "price": target_buy_price,
            "sl": round(target_buy_price - (SL_POINTS * point), digits),
            "tp": round(target_buy_price + (TP_POINTS * point), digits),
            "deviation": 20,
            "magic": MAGIC_NUMBER,
            "comment": "GOLD_HFT_EXPANSION",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling,
        }
        res = mt5.order_send(req)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            log.info("Placed Buy Stop @ %.*f (ATR: $%.2f, CHOP: %.1f)", digits, target_buy_price, atr, chop)
        else:
            err = res.comment if res else mt5.last_error()
            log.warning("Buy Stop Send Failed: %s (code %s)", err, getattr(res, 'retcode', 'None'))
    elif abs(buy_stops[0].price_open - target_buy_price) > (2500 * point):
        # Cancel and re-center
        mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": buy_stops[0].ticket})

    # Re-center Sell Stop if displaced > 10 pips
    if not sell_stops:
        req = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": SYMBOL,
            "volume": LOT_SIZE,
            "type": mt5.ORDER_TYPE_SELL_STOP,
            "price": target_sell_price,
            "sl": round(target_sell_price + (SL_POINTS * point), digits),
            "tp": round(target_sell_price - (TP_POINTS * point), digits),
            "deviation": 20,
            "magic": MAGIC_NUMBER,
            "comment": "GOLD_HFT_EXPANSION",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling,
        }
        res = mt5.order_send(req)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            log.info("Placed Sell Stop @ %.*f (ATR: $%.2f, CHOP: %.1f)", digits, target_sell_price, atr, chop)
        else:
            err = res.comment if res else mt5.last_error()
            log.warning("Sell Stop Send Failed: %s (code %s)", err, getattr(res, 'retcode', 'None'))
    elif abs(sell_stops[0].price_open - target_sell_price) > (2500 * point):
        # Cancel and re-center
        mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": sell_stops[0].ticket})

def run():
    log.info("Starting Mission Charlie: Gold HFT ATR & Chop Sentinel on #%d...", ACCOUNT_ID)
    if not mt5.initialize(path=TERMINAL_PATH, portable=True):
        log.critical("Failed to connect to Terminal 3 at %s", TERMINAL_PATH)
        return

    try:
        while True:
            try:
                sync_gold_straddle()
            except Exception as e:
                log.error("Cycle error: %s", e)
            time.sleep(5)
    except KeyboardInterrupt:
        log.info("Shutdown requested.")
    finally:
        mt5.shutdown()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--probe":
        if mt5.initialize(path=TERMINAL_PATH, portable=True):
            rates = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M5, 0, 30)
            atr, chop = calculate_atr_and_chop(rates)
            now_utc = datetime.now(timezone.utc)
            is_asian = (now_utc.hour >= 22 or now_utc.hour < 6)
            min_atr = MIN_ATR_ASIAN if is_asian else MIN_ATR_NORMAL
            print("=" * 60)
            print("[*] GOLD VOLATILITY & CHOP DIAGNOSTIC:")
            print(f"    • Symbol          : {SYMBOL}")
            print(f"    • M5 ATR (14)     : ${atr:.2f} (Required: >= ${min_atr:.2f})")
            print(f"    • Choppiness Index: {chop} (Required: < {CHOP_THRESHOLD})")
            print(f"    • Session Window  : {'ASIAN (Strict Filter)' if is_asian else 'LDN/NY (Standard Filter)'}")
            print(f"    • Straddle Action : {'ARMED (Volatility expansion confirmed)' if (atr >= min_atr and chop < CHOP_THRESHOLD) else 'BLOCKED (Chop suppression active)'}")
            print("=" * 60)
            mt5.shutdown()
        else:
            print("[-] Could not initialize MT5 Terminal 3.")
    else:
        run()
