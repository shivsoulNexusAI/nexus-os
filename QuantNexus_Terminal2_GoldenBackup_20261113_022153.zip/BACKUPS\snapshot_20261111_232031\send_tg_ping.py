import re
import httpx
from pathlib import Path

reporter_path = Path(r"C:\Quant-Nexus-Eng\weekly_alpha_reporter.py")
text = reporter_path.read_text(encoding="utf-8")

token_match = re.search(r"TELEGRAM_BOT_TOKEN\s*=\s*['\"]([^'\"]+)['\"]", text) or re.search(r"BOT_TOKEN\s*=\s*['\"]([^'\"]+)['\"]", text)
chat_match = re.search(r"TELEGRAM_CHAT_ID\s*=\s*['\"]([^'\"]+)['\"]", text) or re.search(r"CHAT_ID\s*=\s*['\"]([^'\"]+)['\"]", text)

if not token_match or not chat_match:
    token_match = re.search(r"([0-9]{8,10}:[a-zA-Z0-9_-]{35})", text)
    chat_match = re.search(r"CHAT_ID\s*=\s*([0-9-]+)", text)

if token_match and chat_match:
    token = token_match.group(1)
    chat_id = chat_match.group(1)
    print(f"[+] Found Token: {token[:6]}...{token[-4:]} | Chat ID: {chat_id}")
    
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": "🟢 [QUANT-NEXUS TELEMETRY HEARTBEAT]\nVPS Headless Session Verified.\nAccount #278041169 | Balance: $1,103.73 | Equity: $1,121.54 (+17.81 float)\nUSDJPY runner protected (+25 pips).",
        "parse_mode": "HTML"
    }
    try:
        r = httpx.post(url, json=payload, timeout=10.0)
        if r.status_code == 200:
            print("[SUCCESS] Test alert transmitted directly to Telegram phone channel!")
        else:
            print(f"[-] Telegram API Error: {r.status_code} - {r.text}")
    except Exception as e:
        print(f"[-] Network connection error: {e}")
else:
    print("[-] Could not parse BOT_TOKEN and CHAT_ID from weekly_alpha_reporter.py.")