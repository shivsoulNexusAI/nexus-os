from pathlib import Path

path = Path(r"C:\Quant-Nexus-Eng\nexus_multi_straddle_daemon.py")
lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING LOT SIZE LOGIC (LINES 175-195)")
print("=" * 85)
for i in range(174, min(len(lines), 195)):
    print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)