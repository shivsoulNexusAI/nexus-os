import re
from pathlib import Path

BASE_DIR = Path(r"C:\Quant-Nexus-Eng")
TARGETS = ["weekly_alpha_reporter.py", "deal_resolution_watcher.py"]

for fname in TARGETS:
    fpath = BASE_DIR / fname
    if not fpath.exists():
        print(f"[-] {fname} not found, skipping.")
        continue

    bak = BASE_DIR / f"{fname}.bak_v43"
    if not bak.exists():
        bak.write_bytes(fpath.read_bytes())

    code = fpath.read_text(encoding="utf-8")
    orig = code

    # 1. Inject 20260440 wherever legacy magic numbers 20260430 or 20260420 appear without 20260440
    if "20260440" not in code:
        if "20260430" in code:
            code = code.replace("20260430", "20260430, 20260440")
            # Fix equality checks if 20260430 was used in == 20260430
            code = re.sub(r"==\s*20260430,\s*20260440", "in (20260430, 20260440)", code)
        elif "20260420" in code:
            code = code.replace("20260420", "20260420, 20260440")
            code = re.sub(r"==\s*20260420,\s*20260440", "in (20260420, 20260440)", code)

    # 2. Inject NEXUS_V44 wherever NEXUS_V43 or NEXUS_V42 comment prefixes appear
    if "NEXUS_V44" not in code:
        for legacy_tag in ("NEXUS_V43", "NEXUS_V42"):
            if f'"{legacy_tag}"' in code:
                code = code.replace(f'"{legacy_tag}"', f'"{legacy_tag}", "NEXUS_V44"')
                code = re.sub(rf'==\s*"{legacy_tag}",\s*"NEXUS_V44"', f'in ("{legacy_tag}", "NEXUS_V44")', code)
            elif f"'{legacy_tag}'" in code:
                code = code.replace(f"'{legacy_tag}'", f"'{legacy_tag}', 'NEXUS_V44'")
                code = re.sub(rf"==\s*'{legacy_tag}',\s*'NEXUS_V44'", f"in ('{legacy_tag}', 'NEXUS_V44')", code)

    if code != orig:
        fpath.write_text(code, encoding="utf-8")
        print(f"[OK] Patched {fname} to include V4.4 magic 20260440 & NEXUS_V44 tags.")
    else:
        print(f"[INFO] {fname} already accepts all account deals / V4.4 tags without restrictive filters.")

    # Print any magic/comment filter lines for transparent audit
    for idx, line in enumerate(code.splitlines(), 1):
        if any(k in line for k in ("202604", "NEXUS_V4", "magic", "comment")):
            if len(line.strip()) < 140:
                print(f"  L{idx}: {line.strip()}")