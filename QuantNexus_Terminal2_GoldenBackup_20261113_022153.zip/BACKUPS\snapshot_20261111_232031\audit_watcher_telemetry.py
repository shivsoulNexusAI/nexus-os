from pathlib import Path

watcher_log = Path(r"C:\Quant-Nexus-Eng\deal_resolution_watcher.log")
watcher_err = Path(r"C:\Quant-Nexus-Eng\deal_resolution_watcher_err.log")

print("=" * 85)
print("DEAL RESOLUTION WATCHER TELEMETRY (PID 8332)")
print("=" * 85)

if watcher_log.exists():
    lines = watcher_log.read_text(encoding="utf-8", errors="ignore").splitlines()
    print(f"Log path: {watcher_log} ({len(lines)} total lines)")
    for l in lines[-10:]:
        print(f"  {l}")
else:
    print("[-] deal_resolution_watcher.log does not exist.")

if watcher_err.exists():
    errs = watcher_err.read_text(encoding="utf-8", errors="ignore").splitlines()
    if errs:
        print("\n--- Recent stderr entries ---")
        for e in errs[-5:]:
            print(f"  {e}")
print("=" * 85)