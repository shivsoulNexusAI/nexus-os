from pathlib import Path

gold_path = Path(r"C:\Quant-Nexus-Eng\gold_hft_straddle_daemon.py")
lines = gold_path.read_text(encoding="utf-8", errors="ignore").splitlines()

print("=" * 85)
print("INSPECTING STRADDLE EVALUATION & ORDER MANAGEMENT LOOP")
print("=" * 85)

for idx, line in enumerate(lines):
    if any(k in line for k in ["def place_straddle", "def manage_straddle", "while True:"]):
        print(f"\n--- Code around line {idx+1}: {line.strip()} ---")
        for i in range(idx, min(len(lines), idx + 35)):
            print(f"{i+1:4d}: {lines[i]}")
print("=" * 85)