import MetaTrader5 as mt5

TERMINAL = r"C:/MT5_HFT_278041671/terminal64.exe"
if mt5.initialize(path=TERMINAL, portable=False, timeout=10000):
    orders = mt5.orders_get(ticket=2854502121)
    tick = mt5.symbol_info_tick("XAUUSD")
    sym = mt5.symbol_info("XAUUSD")
    
    print("=" * 85)
    print("ORPHAN ORDER AUDIT: ACCOUNT #278041671")
    print("=" * 85)
    if orders:
        o = orders[0]
        print(f"Order #{o.ticket} | Symbol: {o.symbol} | Type: BUY_STOP | Open Price: {o.price_open:.3f}")
        print(f"SL: {o.sl:.3f} | TP: {o.tp:.3f} | Current Bid: {tick.bid:.3f} | Current Ask: {tick.ask:.3f}")
        print(f"Distance to Spot Ask: ${(o.price_open - tick.ask):.3f}")
    else:
        print("[i] Order #2854502121 no longer exists (either filled, expired, or removed).")
    mt5.shutdown()
    print("=" * 85)
else:
    print("[-] Failed to initialize Terminal 3.")